/**
 * Gestão de Contratos e CAPEX - Coordenação da Aplicação
 * Desenvolvido em Vanilla JS puro, integrado ao Supabase via CDN
 */

// Chaves de Acesso e Inicialização do Cliente Supabase
// Utilizamos as variáveis injetadas pelo ambiente do AI Studio (.env.example)
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || "https://vummhunvihwwhwmozadp.supabase.co";
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "sb_publishable_PmvDLlgHcza-dCGlPTSNfA_T6IwyhqP";

class MockSupabaseClient {
  constructor() {
    this.initData();
  }

  initData() {
    const contractsStr = localStorage.getItem("aegea_contracts");
    if (contractsStr && (contractsStr.includes("CON-001") || !contractsStr.includes("23015.E.EE") || !contractsStr.includes("liberar_leitura_capex"))) {
      // Força a limpeza do cache legado para migrar para os dados reais de estrutura PEP
      localStorage.removeItem("aegea_contracts");
      localStorage.removeItem("aegea_monthly");
      localStorage.removeItem("aegea_razao");
      localStorage.removeItem("aegea_documents");
    }

    if (!localStorage.getItem("aegea_contracts")) {
      const defaultContracts = [
        { codigo: "23015.E.EE", nome: "ETA Guandu - Reservas e Estação Elevatória", status: "Iniciado", capex_orcado: 12500000, arquivo_contrato: null, liberar_leitura_capex: true },
        { codigo: "24016.E.TE", nome: "Coletor Tronco de Esgoto e Estação Tratamento", status: "Iniciado", capex_orcado: 8200000, arquivo_contrato: null, liberar_leitura_capex: true },
        { codigo: "23017.E.RC", nome: "Rede Coletora Básica - Booster Zona Leste", status: "Concluído", capex_orcado: 3500000, arquivo_contrato: null, liberar_leitura_capex: false },
        { codigo: "24018.E.LD", nome: "Ligações Domiciliares - Extremo Sul", status: "Iniciado", capex_orcado: 1800000, arquivo_contrato: null, liberar_leitura_capex: true },
        { codigo: "25019.E.LR", nome: "Linha de Recalque ETE Capivari - Ampliação", status: "Não Iniciado", capex_orcado: 17500000, arquivo_contrato: null, liberar_leitura_capex: true }
      ];
      localStorage.setItem("aegea_contracts", JSON.stringify(defaultContracts));
    }

    if (!localStorage.getItem("aegea_monthly")) {
      const defaultMonthly = [
        // Janeiro 2026
        { ano: 2026, mes: 1, mes_nome: "Janeiro", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Orçado", valor: 1500000 },
        { ano: 2026, mes: 1, mes_nome: "Janeiro", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Realizado", valor: 1200000 },
        { ano: 2026, mes: 1, mes_nome: "Janeiro", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Orçado", valor: 800000 },
        { ano: 2026, mes: 1, mes_nome: "Janeiro", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Realizado", valor: 600000 },

        // Fevereiro 2026
        { ano: 2026, mes: 2, mes_nome: "Fevereiro", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Orçado", valor: 1500000 },
        { ano: 2026, mes: 2, mes_nome: "Fevereiro", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Realizado", valor: 1400000 },
        { ano: 2026, mes: 2, mes_nome: "Fevereiro", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Orçado", valor: 800000 },
        { ano: 2026, mes: 2, mes_nome: "Fevereiro", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Realizado", valor: 750000 },

        // Março 2026
        { ano: 2026, mes: 3, mes_nome: "Março", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Orçado", valor: 2000000 },
        { ano: 2026, mes: 3, mes_nome: "Março", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Realizado", valor: 1950000 },
        { ano: 2026, mes: 3, mes_nome: "Março", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Orçado", valor: 1000000 },
        { ano: 2026, mes: 3, mes_nome: "Março", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Realizado", valor: 900000 },

        // Abril 2026
        { ano: 2026, mes: 4, mes_nome: "Abril", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Orçado", valor: 2000000 },
        { ano: 2026, mes: 4, mes_nome: "Abril", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Realizado", valor: 2100000 },
        { ano: 2026, mes: 4, mes_nome: "Abril", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Orçado", valor: 1200000 },
        { ano: 2026, mes: 4, mes_nome: "Abril", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Realizado", valor: 1100000 },

        // Maio 2026
        { ano: 2026, mes: 5, mes_nome: "Maio", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Orçado", valor: 2500000 },
        { ano: 2026, mes: 5, mes_nome: "Maio", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Realizado", valor: 2300000 },
        { ano: 2026, mes: 5, mes_nome: "Maio", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Orçado", valor: 1500000 },
        { ano: 2026, mes: 5, mes_nome: "Maio", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Realizado", valor: 1300000 },

        // Junho 2026
        { ano: 2026, mes: 6, mes_nome: "Junho", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Orçado", valor: 3000000 },
        { ano: 2026, mes: 6, mes_nome: "Junho", indicador: "ETA Guandu - Reservas e Estação Elevatória", tipo: "Realizado", valor: 2850000 },
        { ano: 2026, mes: 6, mes_nome: "Junho", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Orçado", valor: 2000000 },
        { ano: 2026, mes: 6, mes_nome: "Junho", indicador: "Coletor Tronco de Esgoto e Estação Tratamento", tipo: "Realizado", valor: 1800000 }
      ];
      localStorage.setItem("aegea_monthly", JSON.stringify(defaultMonthly));
    }

    if (!localStorage.getItem("aegea_razao")) {
      const defaultRazao = [
        { mes: 1, mes_nome: "Janeiro", elemento_pep: "O/EST.23015.E.EE.I.00101", projeto: "23015.E.EE", nf: "NF-202601", fornecedor: "Alpha Saneamento Ltda", valor: 350000 },
        { mes: 1, mes_nome: "Janeiro", elemento_pep: "O/EST.23015.E.EE.I.00102", projeto: "23015.E.EE", nf: "NF-202602", fornecedor: "Beta Obras de Infraestrutura", valor: 450000 },
        { mes: 1, mes_nome: "Janeiro", elemento_pep: "O/EST.24016.E.TE.I.00201", projeto: "24016.E.TE", nf: "NF-202603", fornecedor: "Gama Tubulações S.A.", valor: 600000 },
        { mes: 2, mes_nome: "Fevereiro", elemento_pep: "O/EST.23015.E.EE.I.00101", projeto: "23015.E.EE", nf: "NF-202604", fornecedor: "Alpha Saneamento Ltda", valor: 500000 },
        { mes: 2, mes_nome: "Fevereiro", elemento_pep: "O/EST.24016.E.TE.I.00202", projeto: "24016.E.TE", nf: "NF-202605", fornecedor: "Gama Tubulações S.A.", valor: 750000 },
        { mes: 3, mes_nome: "Março", elemento_pep: "O/EST.23015.E.EE.I.00102", projeto: "23015.E.EE", nf: "NF-202606", fornecedor: "Alpha Saneamento Ltda", valor: 800000 },
        { mes: 3, mes_nome: "Março", elemento_pep: "O/EST.25019.E.LR.I.00501", projeto: "25019.E.LR", nf: "NF-202607", fornecedor: "Delta Hidráulica Eireli", valor: 1200000 },
        { mes: 3, mes_nome: "Março", elemento_pep: "O/EST.24016.E.TE.I.00201", projeto: "24016.E.TE", nf: "NF-202608", fornecedor: "Beta Obras de Infraestrutura", valor: 900000 },
        { mes: 4, mes_nome: "Abril", elemento_pep: "O/EST.23017.E.RC.I.00301", projeto: "23017.E.RC", nf: "NF-202609", fornecedor: "Mega Construtora e Locações", valor: 1100000 },
        { mes: 4, mes_nome: "Abril", elemento_pep: "O/EST.23015.E.EE.I.00101", projeto: "23015.E.EE", nf: "NF-202610", fornecedor: "Alpha Saneamento Ltda", valor: 950000 },
        { mes: 5, mes_nome: "Maio", elemento_pep: "O/EST.23015.E.EE.I.00102", projeto: "23015.E.EE", nf: "NF-202611", fornecedor: "Alpha Saneamento Ltda", valor: 1300000 },
        { mes: 5, mes_nome: "Maio", elemento_pep: "O/EST.24016.E.TE.I.00202", projeto: "24016.E.TE", nf: "NF-202612", fornecedor: "Gama Tubulações S.A.", valor: 1300000 },
        { mes: 5, mes_nome: "Maio", elemento_pep: "O/EST.24018.E.LD.I.00401", projeto: "24018.E.LD", nf: "NF-202613", fornecedor: "PerfuraSul Sondagens", valor: 450000 },
        { mes: 6, mes_nome: "Junho", elemento_pep: "O/EST.25019.E.LR.I.00501", projeto: "25019.E.LR", nf: "NF-202614", fornecedor: "Delta Hidráulica Eireli", valor: 1850000 },
        { mes: 6, mes_nome: "Junho", elemento_pep: "O/EST.24016.E.TE.I.00201", projeto: "24016.E.TE", nf: "NF-202615", fornecedor: "Beta Obras de Infraestrutura", valor: 1800000 },
        { mes: 6, mes_nome: "Junho", elemento_pep: "O/EST.23017.E.RC.I.00301", projeto: "23017.E.RC", nf: "NF-202616", fornecedor: "Mega Construtora e Locações", valor: 700000 }
      ];
      localStorage.setItem("aegea_razao", JSON.stringify(defaultRazao));
    }

    if (!localStorage.getItem("aegea_documents")) {
      const defaultDocs = [
        { contrato: "23015.E.EE", tipo: "contrato", nome_arquivo: "Contrato_Guandu_Reservas_Assinado.pdf", url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf", data_documento: "2026-01-10" },
        { contrato: "24016.E.TE", tipo: "licença", nome_arquivo: "Licenca_Ambiental_Instalacao_Socio.pdf", url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf", data_documento: "2026-02-15" },
        { contrato: "23017.E.RC", tipo: "projeto", nome_arquivo: "Projeto_Básico_Booster_Leste_Rev02.pdf", url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf", data_documento: "2026-03-01" },
        { contrato: "25019.E.LR", tipo: "medição", nome_arquivo: "Medicao_Fisica_01_Ampliacao_ETE.pdf", url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf", data_documento: "2026-05-20" }
      ];
      localStorage.setItem("aegea_documents", JSON.stringify(defaultDocs));
    }

    if (!localStorage.getItem("aegea_planejamento")) {
      const defaultPlanejamento = [
        { ano: 2026, mes: 1, contrato: "23015.E.EE", valor_previsto: 1500000 },
        { ano: 2026, mes: 1, contrato: "24016.E.TE", valor_previsto: 800000 },
        { ano: 2026, mes: 2, contrato: "23015.E.EE", valor_previsto: 1500000 },
        { ano: 2026, mes: 2, contrato: "24016.E.TE", valor_previsto: 800000 },
        { ano: 2026, mes: 3, contrato: "23015.E.EE", valor_previsto: 2000000 },
        { ano: 2026, mes: 3, contrato: "24016.E.TE", valor_previsto: 1000000 },
        { ano: 2026, mes: 3, contrato: "25019.E.LR", valor_previsto: 1200000 },
        { ano: 2026, mes: 4, contrato: "23015.E.EE", valor_previsto: 2000000 },
        { ano: 2026, mes: 4, contrato: "24016.E.TE", valor_previsto: 1200000 },
        { ano: 2026, mes: 4, contrato: "23017.E.RC", valor_previsto: 1100000 },
        { ano: 2026, mes: 5, contrato: "23015.E.EE", valor_previsto: 2500000 },
        { ano: 2026, mes: 5, contrato: "24016.E.TE", valor_previsto: 1500000 },
        { ano: 2026, mes: 5, contrato: "24018.E.LD", valor_previsto: 450000 },
        { ano: 2026, mes: 6, contrato: "23015.E.EE", valor_previsto: 3000000 },
        { ano: 2026, mes: 6, contrato: "24016.E.TE", valor_previsto: 2000000 },
        { ano: 2026, mes: 6, contrato: "23017.E.RC", valor_previsto: 750000 },
        { ano: 2026, mes: 6, contrato: "25019.E.LR", valor_previsto: 1850000 }
      ];
      localStorage.setItem("aegea_planejamento", JSON.stringify(defaultPlanejamento));
    }
  }

  getContracts() {
    return JSON.parse(localStorage.getItem("aegea_contracts") || "[]");
  }

  saveContracts(data) {
    localStorage.setItem("aegea_contracts", JSON.stringify(data));
  }

  getMonthly() {
    return JSON.parse(localStorage.getItem("aegea_monthly") || "[]");
  }

  saveMonthly(data) {
    localStorage.setItem("aegea_monthly", JSON.stringify(data));
  }

  getRazao() {
    return JSON.parse(localStorage.getItem("aegea_razao") || "[]");
  }

  saveRazao(data) {
    localStorage.setItem("aegea_razao", JSON.stringify(data));
  }

  getDocuments() {
    return JSON.parse(localStorage.getItem("aegea_documents") || "[]");
  }

  saveDocuments(data) {
    localStorage.setItem("aegea_documents", JSON.stringify(data));
  }

  getPlanejamento() {
    return JSON.parse(localStorage.getItem("aegea_planejamento") || "[]");
  }

  savePlanejamento(data) {
    localStorage.setItem("aegea_planejamento", JSON.stringify(data));
  }

  from(tableName) {
    const client = this;
    let dataToQuery = [];
    
    if (tableName === "contratos") {
      dataToQuery = client.getContracts();
    } else if (tableName === "capex_monitoramento_mensal_") {
      dataToQuery = client.getMonthly();
    } else if (tableName === "razao_2026") {
      dataToQuery = client.getRazao();
    } else if (tableName === "documentos") {
      dataToQuery = client.getDocuments();
    } else if (tableName === "capex_por_contrato") {
      const contracts = client.getContracts();
      const monthly = client.getMonthly();
      
      dataToQuery = contracts.map(c => {
        const utilizado = monthly
          .filter(m => String(m.indicador || "").trim() === String(c.nome || "").trim() && String(m.tipo || "").toLowerCase().trim() === "realizado")
          .reduce((acc, curr) => acc + (parseFloat(curr.valor) || 0), 0);
        
        const saldo = (parseFloat(c.capex_orcado) || 0) - utilizado;
        const percentual = c.capex_orcado > 0 ? (utilizado / parseFloat(c.capex_orcado)) * 100 : 0;
        
        return {
          ...c,
          capex_utilizado: utilizado,
          saldo_capex: saldo,
          percentual_execucao: percentual
        };
      });
    } else if (tableName === "dashboard_financeiro") {
      const contracts = client.getContracts();
      const monthly = client.getMonthly();
      
      const totalContratos = contracts.length;
      const totalAtivos = contracts.filter(c => {
        const normalStatus = String(c.status || "").toLowerCase().trim();
        return normalStatus === "iniciado";
      }).length;
      
      const capexOrcadoTotal = contracts.reduce((acc, curr) => acc + (parseFloat(curr.capex_orcado) || 0), 0);
      const capexUtilizadoTotal = monthly
        .filter(m => String(m.tipo || "").toLowerCase().trim() === "realizado")
        .reduce((acc, curr) => acc + (parseFloat(curr.valor) || 0), 0);
      
      const saldoCapex = capexOrcadoTotal - capexUtilizadoTotal;
      const percentualExecucao = capexOrcadoTotal > 0 ? (capexUtilizadoTotal / capexOrcadoTotal) * 100 : 0;
      
      dataToQuery = [{
        total_contratos: totalContratos,
        total_ativos: totalAtivos,
        capex_orcado_total: capexOrcadoTotal,
        capex_utilizado_total: capexUtilizadoTotal,
        saldo_capex: saldoCapex,
        percentual_execucao: percentualExecucao
      }];
    } else if (tableName === "view_custo_execucao_contrato") {
      const contracts = client.getContracts();
      const monthly = client.getMonthly();
      
      dataToQuery = contracts.map(c => {
        const utilizado = monthly
          .filter(m => String(m.indicador || "").trim() === String(c.nome || "").trim() && String(m.tipo || "").toLowerCase().trim() === "realizado")
          .reduce((acc, curr) => acc + (parseFloat(curr.valor) || 0), 0);
        
        const saldo = (parseFloat(c.capex_orcado) || 0) - utilizado;
        const percentual = c.capex_orcado > 0 ? (utilizado / parseFloat(c.capex_orcado)) * 100 : 0;
        
        return {
          codigo: c.codigo,
          nome: c.nome,
          status: c.status,
          capex_orcado: c.capex_orcado,
          custo_execucao: utilizado,
          saldo: saldo,
          percentual_execucao: percentual
        };
      });
    } else if (tableName === "planejamento_obra") {
      dataToQuery = client.getPlanejamento();
    } else if (tableName === "view_planejado_executado_custo" || tableName === "view_planejado_executado_custo_ate_hoje" || tableName === "curva_s_completa") {
      const plan = client.getPlanejamento();
      const r2026 = client.getRazao();
      
      const joinedRows = [];
      plan.forEach(p => {
        const matches = r2026.filter(r => String(p.contrato || "").trim() === String(r.projeto || "").trim() && (parseInt(r.mes) || 0) === (parseInt(p.mes) || 0));
        if (matches.length === 0) {
          joinedRows.push({
            ano: p.ano,
            mes: p.mes,
            valor_previsto: parseFloat(p.valor_previsto) || 0,
            valor_executado: 0
          });
        } else {
          matches.forEach(r => {
            joinedRows.push({
              ano: p.ano,
              mes: p.mes,
              valor_previsto: parseFloat(p.valor_previsto) || 0,
              valor_executado: parseFloat(r.valor) || 0
            });
          });
        }
      });

      const aggregated = {};
      joinedRows.forEach(row => {
        const key = `${row.ano}-${row.mes}`;
        if (!aggregated[key]) {
          aggregated[key] = {
            ano: row.ano,
            mes: row.mes,
            sum_previsto: 0,
            sum_executado: 0
          };
        }
        aggregated[key].sum_previsto += row.valor_previsto;
        aggregated[key].sum_executado += row.valor_executado;
      });

      let results = Object.values(aggregated).map(item => {
        const diferenca = item.sum_executado - item.sum_previsto;
        const percentual_execucao = item.sum_previsto === 0 ? 0 : (item.sum_executado / item.sum_previsto) * 100;
        return {
          ano: item.ano,
          mes: item.mes,
          previsto: item.sum_previsto,
          executado: item.sum_executado,
          diferenca: diferenca,
          percentual_execucao: percentual_execucao
        };
      }).sort((a,b) => (a.ano - b.ano) || (a.mes - b.mes));

      if (tableName === "view_planejado_executado_custo_ate_hoje") {
        const curYear = new Date().getFullYear();
        const curMonth = getMesAtual();
        results = results.filter(item => (parseInt(item.ano) || 0) === curYear && (parseInt(item.mes) || 0) <= curMonth);
      } else if (tableName === "curva_s_completa") {
        const curYear = new Date().getFullYear();
        const curMonth = getMesAtual();
        let ateHoje = results.filter(item => (parseInt(item.ano) || 0) === curYear && (parseInt(item.mes) || 0) <= curMonth);
        let runningPrevisto = 0;
        let runningExecutado = 0;
        results = ateHoje.map(item => {
          runningPrevisto += parseFloat(item.previsto) || 0;
          runningExecutado += parseFloat(item.executado) || 0;
          return {
            ano: item.ano,
            mes: item.mes,
            previsto_acumulado: runningPrevisto,
            executado_acumulado: runningExecutado
          };
        });
      }

      dataToQuery = results;
    }

    const builder = {
      dataList: dataToQuery,
      orderFields: [],

      select(fields) {
        return this;
      },

      order(field, options = { ascending: true }) {
        this.orderFields.push({ field, ascending: options.ascending !== false });
        
        if (field) {
          this.dataList.sort((a, b) => {
            for (let ord of this.orderFields) {
              const vA = a[ord.field];
              const vB = b[ord.field];
              if (vA !== vB) {
                if (vA === undefined || vA === null) return 1;
                if (vB === undefined || vB === null) return -1;
                if (typeof vA === "number" && typeof vB === "number") {
                  return ord.ascending ? vA - vB : vB - vA;
                }
                return ord.ascending 
                  ? String(vA).localeCompare(String(vB)) 
                  : String(vB).localeCompare(String(vA));
              }
            }
            return 0;
          });
        }
        return this;
      },

      eq(field, value) {
        this.dataList = this.dataList.filter(item => String(item[field]) === String(value));
        return this;
      },

      then(onfulfilled, onrejected) {
        const response = { data: this.dataList, error: null };
        return Promise.resolve(response).then(onfulfilled, onrejected);
      },

      async insert(records) {
        try {
          if (tableName === "contratos") {
            const current = client.getContracts();
            records.forEach(r => {
              current.push({
                codigo: r.codigo,
                nome: r.nome,
                status: r.status || "Não Iniciado",
                capex_orcado: parseFloat(r.capex_orcado) || 0,
                capex_utilizado: parseFloat(r.capex_utilizado) || 0
              });
            });
            client.saveContracts(current);
          } else if (tableName === "capex_monitoramento_mensal_") {
            const current = client.getMonthly();
            records.forEach(r => {
              current.push({
                ano: parseInt(r.ano) || 2026,
                mes: parseInt(r.mes) || 1,
                mes_nome: r.mes_nome,
                indicador: r.indicador,
                tipo: r.tipo,
                valor: parseFloat(r.valor) || 0
              });
            });
            client.saveMonthly(current);
          } else if (tableName === "documentos") {
            const current = client.getDocuments();
            records.forEach(r => {
              current.push({
                contrato: r.contrato,
                tipo: r.tipo,
                nome_arquivo: r.nome_arquivo,
                url: r.url,
                data_documento: r.data_documento || new Date().toISOString().split('T')[0]
              });
            });
            client.saveDocuments(current);
          } else if (tableName === "planejamento_obra") {
            const current = client.getPlanejamento();
            records.forEach(r => {
              current.push({
                ano: parseInt(r.ano) || 2026,
                mes: parseInt(r.mes) || 1,
                contrato: r.contrato,
                valor_previsto: parseFloat(r.valor_previsto) || 0
              });
            });
            client.savePlanejamento(current);
          }
          return { data: records, error: null };
        } catch (e) {
          return { data: null, error: e };
        }
      },

      async delete() {
        this.isDelete = true;
        return this;
      },

      async update(fields) {
        this.updateFields = fields;
        return this;
      },

      async eq(field, value) {
        if (this.isDelete) {
          if (tableName === "documentos") {
            const current = client.getDocuments();
            const filtered = current.filter(item => String(item[field]) !== String(value));
            client.saveDocuments(filtered);
          }
          this.isDelete = false;
          return { data: null, error: null };
        }

        if (this.updateFields) {
          if (tableName === "contratos") {
            const current = client.getContracts();
            current.forEach(item => {
              if (String(item[field]) === String(value)) {
                Object.assign(item, this.updateFields);
              }
            });
            client.saveContracts(current);
          } else if (tableName === "capex_monitoramento_mensal_") {
            const current = client.getMonthly();
            current.forEach(item => {
              if (String(item[field]) === String(value)) {
                Object.assign(item, this.updateFields);
              }
            });
            client.saveMonthly(current);
          }
          this.updateFields = null;
          return { data: null, error: null };
        }
        
        this.dataList = this.dataList.filter(item => String(item[field]) === String(value));
        return { data: this.dataList, error: null };
      }
    };

    return builder;
  }
}

let supabaseClient = null;
let supabase = null;

// Formatação Monetária Brasileira e Percentual
function getMesAtual() {
  return new Date().getMonth() + 1;
}

function formatBRL(value) {
  if (value === undefined || value === null || isNaN(value)) return "R$ 0,00";
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

function formatPercent(value) {
  if (value === undefined || value === null || isNaN(value)) return "0,00%";
  // Caso venha como decimal (ex: 0.854 em vez de 85.4)
  let num = parseFloat(value);
  return num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "%";
}

// ==========================================================
// CENTRALIZAÇÃO DA AUTENTICAÇÃO INTEGRAGEST (AEGEA SANEAMENTO)
// ==========================================================
function checkAuthentication(onSuccess) {
  const sessionAuth = localStorage.getItem("session_authenticated");
  const sessionEmail = localStorage.getItem("session_email");

  if (sessionAuth === "true" && sessionEmail) {
    // Usuário já está logado!
    renderAuthUI(sessionEmail);
    onSuccess();
    return;
  }

  // Se não estiver logado, bloqueia a exibição de todo o site
  document.body.classList.add("not-logged-in");

  // Injeta estilos de bloqueio adicionais se não existirem
  if (!document.getElementById("auth-styles")) {
    const styleEl = document.createElement("style");
    styleEl.id = "auth-styles";
    styleEl.innerHTML = `
      body.not-logged-in {
        overflow: hidden !important;
        height: 100vh !important;
      }
      body.not-logged-in > *:not(#auth-barrier) {
        display: none !important;
      }
    `;
    document.head.appendChild(styleEl);
  }

  // Cria o overlay do Login
  const authBarrier = document.createElement("div");
  authBarrier.id = "auth-barrier";
  authBarrier.className = "fixed inset-0 bg-[#071324] flex items-center justify-center z-[999999] overflow-y-auto px-4 py-8 font-sans selection:bg-[#00c2a8] selection:text-slate-900";
  authBarrier.innerHTML = `
    <!-- Top Soft Ambient Light Glow -->
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[450px] bg-gradient-to-b from-[#00c2a8]/10 to-transparent blur-[120px] pointer-events-none"></div>

    <div class="relative w-full max-w-md bg-[#0b1f3a]/90 backdrop-blur-md rounded-2xl border border-slate-800 p-8 shadow-2xl transition hover:border-[#00c2a8]/30">
      <!-- Logo Header -->
      <div class="flex flex-col items-center mb-8 select-none">
        <div class="p-3 bg-gradient-to-br from-[#00c2a8] to-[#0142C6] rounded-2xl text-white shadow-lg flex items-center justify-center mb-4">
          <svg style="width: 24px; height: 24px" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <h2 class="text-white text-2xl font-bold font-space tracking-tight">IntegraGest</h2>
        <p class="text-xs text-teal-400 font-bold tracking-widest uppercase mt-0.5 font-space">Aegea Saneamento • ID Único</p>
      </div>

      <!-- Mode Selector Tab -->
      <div class="flex bg-[#071324] p-1 rounded-xl border border-slate-800 mb-6 font-medium text-xs">
        <button id="tab-login" type="button" class="flex-1 py-2 text-center rounded-lg transition-all text-white bg-teal-500/10 border border-teal-500/20 font-bold font-space">
          Entrar
        </button>
        <button id="tab-register" type="button" class="flex-1 py-2 text-center rounded-lg transition-all text-slate-400 hover:text-white font-space">
          Criar Conta
        </button>
      </div>

      <!-- Alert Dialog -->
      <div id="auth-feedback" class="hidden mb-6 p-4 rounded-xl text-xs font-semibold border transition-all duration-300"></div>

      <!-- Form -->
      <form id="auth-form" class="space-y-5">
        <div>
          <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">E-mail Corporativo *</label>
          <div class="relative">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 text-sm">
              ✉
            </span>
            <input type="email" id="auth-email-input" required placeholder="gabriellarodrigues@ucl.br" class="w-full bg-slate-900/60 hover:bg-slate-900/80 focus:bg-[#071324] text-white pl-10 pr-4 py-2.5 rounded-xl border border-slate-800 focus:border-teal-500 outline-none text-sm transition font-medium">
          </div>
        </div>

        <div>
          <div class="flex justify-between items-center mb-2">
            <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">Senha Secreta *</label>
            <span class="text-[10px] text-slate-500">Mínimo 6 caracteres</span>
          </div>
          <div class="relative">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 text-sm">
              🔒
            </span>
            <input type="password" id="auth-password-input" required placeholder="Insira sua senha..." class="w-full bg-slate-900/60 hover:bg-slate-900/80 focus:bg-[#071324] text-white pl-10 pr-10 py-2.5 rounded-xl border border-slate-800 focus:border-teal-500 outline-none text-sm transition font-medium">
            <button type="button" id="btn-toggle-view-pass" class="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-500 hover:text-slate-300 text-xs">
              <span id="pass-eye-symbol">👁</span>
            </button>
          </div>
        </div>

        <!-- Submit Button -->
        <button type="submit" id="auth-submit-btn" class="w-full py-3 bg-[#00c2a8] hover:bg-[#00b097] text-slate-950 font-bold rounded-xl shadow-lg shadow-teal-500/10 hover:shadow-teal-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center space-x-2 text-sm font-space cursor-pointer">
          <span>Entrar</span>
        </button>
      </form>

      <!-- Support info -->
      <div class="mt-8 pt-6 border-t border-slate-800/80 flex flex-col items-center gap-2">
        <div id="auth-mode-indicator" class="flex items-center space-x-1.5 text-[10px] text-teal-400 font-medium px-2.5 py-1 bg-slate-900/60 rounded-full border border-slate-800">
          <span class="w-1.5 h-1.5 bg-[#00c2a8] rounded-full animate-pulse"></span>
          <span id="auth-mode-text">Análise do Sistema</span>
        </div>
        <p class="text-[9px] text-slate-500 leading-relaxed text-center">
          O acesso requer autenticação centralizada do sistema Aegea Saneamento. Seus dados estão em conformidade com as diretrizes LGPD.
        </p>
      </div>
    </div>
  `;

  document.body.appendChild(authBarrier);

  // Instancia elementos
  const tabLogin = document.getElementById("tab-login");
  const tabRegister = document.getElementById("tab-register");
  const authForm = document.getElementById("auth-form");
  const authFeedback = document.getElementById("auth-feedback");
  const emailInput = document.getElementById("auth-email-input");
  const passwordInput = document.getElementById("auth-password-input");
  const submitBtn = document.getElementById("auth-submit-btn");
  const togglePassBtn = document.getElementById("btn-toggle-view-pass");
  const passEyeSymbol = document.getElementById("pass-eye-symbol");
  const authModeIndicator = document.getElementById("auth-mode-indicator");
  const authModeText = document.getElementById("auth-mode-text");

  let authMode = "login"; // "login" ou "register"

  // Detecta se Supabase é Mock ou Real
  // O SDK do Supabase está carregado se window.supabase && window.supabase.createClient estão presentes e as chaves não são fake
  const isMockEnv = !window.supabase || (typeof window.supabase.createClient === "undefined") || !import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY.startsWith("sb_publishable_");

  if (isMockEnv) {
    authModeText.textContent = "Modo de Demonstração (Local)";
    authModeIndicator.className = "flex items-center space-x-1.5 text-[10px] text-amber-500 font-medium px-2.5 py-1 bg-amber-500/10 rounded-full border border-amber-500/20";
    authModeIndicator.querySelector("span").className = "w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse";
  } else {
    authModeText.textContent = "Supabase Corporativo Conectado";
    authModeIndicator.className = "flex items-center space-x-1.5 text-[10px] text-teal-400 font-medium px-2.5 py-1 bg-slate-900/60 rounded-full border border-slate-800";
    authModeIndicator.querySelector("span").className = "w-1.5 h-1.5 bg-[#00c2a8] rounded-full animate-pulse";
  }

  // Toggles de visualização de Senha
  if (togglePassBtn) {
    togglePassBtn.addEventListener("click", () => {
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        passEyeSymbol.textContent = "🙈";
      } else {
        passwordInput.type = "password";
        passEyeSymbol.textContent = "👁";
      }
    });
  }

  // Toggle de abas
  const switchMode = (mode) => {
    authMode = mode;
    authFeedback.classList.add("hidden");
    if (mode === "login") {
      tabLogin.className = "flex-1 py-2 text-center rounded-lg transition-all text-white bg-teal-500/10 border border-teal-500/20 font-bold font-space";
      tabRegister.className = "flex-1 py-2 text-center rounded-lg transition-all text-slate-400 hover:text-white font-space";
      submitBtn.querySelector("span").textContent = "Entrar";
    } else {
      tabRegister.className = "flex-1 py-2 text-center rounded-lg transition-all text-white bg-teal-500/10 border border-teal-500/20 font-bold font-space";
      tabLogin.className = "flex-1 py-2 text-center rounded-lg transition-all text-slate-400 hover:text-white font-space";
      submitBtn.querySelector("span").textContent = "Cadastrar Novo Usuário";
    }
  };

  tabLogin.addEventListener("click", () => switchMode("login"));
  tabRegister.addEventListener("click", () => switchMode("register"));

  // Envio de formulário
  authForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (!email || !password) {
      showFeedbackMsg("Preencha todos os campos obrigatórios.", "bg-rose-500/10 text-rose-400 border-rose-500/20");
      return;
    }

    if (password.length < 6) {
      showFeedbackMsg("A senha deve ter no mínimo 6 caracteres.", "bg-rose-500/10 text-rose-400 border-rose-500/20");
      return;
    }

    // Feedback visual de carregamento
    submitBtn.disabled = true;
    const oldText = submitBtn.querySelector("span").textContent;
    submitBtn.querySelector("span").textContent = "Processando requisição...";

    try {
      if (isMockEnv) {
        // --- AMBIENTE DE DEMONSTRACAO LOCAL ---
        const localUsers = JSON.parse(localStorage.getItem("aegea_users") || "[]");

        if (authMode === "login") {
          // Checa se existe e bate a senha
          const matchedUser = localUsers.find(u => String(u.email).toLowerCase().trim() === String(email).toLowerCase().trim());
          
          if (matchedUser) {
            if (matchedUser.password === password) {
              completeLogin(email);
            } else {
              throw new Error("Senha incorreta cadastrada para esta simulação.");
            }
          } else {
            // Se for login e for o primeiro acesso no demo, pra ser super conveniente e amigável,
            // salvamos e logamos automaticamente informando o usuário
            localUsers.push({ email, password });
            localStorage.setItem("aegea_users", JSON.stringify(localUsers));
            completeLogin(email);
          }
        } else {
          // Cadastro
          const matchedUser = localUsers.find(u => String(u.email).toLowerCase().trim() === String(email).toLowerCase().trim());
          if (matchedUser) {
            throw new Error("Este e-mail já está cadastrado localmente nesta simulação.");
          }

          localUsers.push({ email, password });
          localStorage.setItem("aegea_users", JSON.stringify(localUsers));
          showFeedbackMsg("Cadastro local efetuado com sucesso! Redirecionando para login...", "bg-emerald-500/10 text-emerald-400 border-emerald-500/20");
          setTimeout(() => {
            switchMode("login");
            submitBtn.disabled = false;
            submitBtn.querySelector("span").textContent = "Entrar";
          }, 1200);
        }

      } else {
        // --- SUPABASE CONECTADO COM SUCESSO ---
        if (authMode === "login") {
          const { data, error } = await window.supabaseClient.auth.signInWithPassword({ email, password });
          if (error) throw error;
          completeLogin(email);
        } else {
          const { data, error } = await window.supabaseClient.auth.signUp({ email, password });
          if (error) throw error;
          showFeedbackMsg("Cadastro realizado com sucesso! Verifique seu e-mail de confirmação ou tente fazer login.", "bg-emerald-500/10 text-emerald-400 border-emerald-500/20");
          setTimeout(() => {
            switchMode("login");
            submitBtn.disabled = false;
            submitBtn.querySelector("span").textContent = "Entrar";
          }, 2000);
        }
      }

    } catch (err) {
      console.error("Erro na autenticação:", err);
      showFeedbackMsg(`Falha na Autenticação: ${err.message || err}`, "bg-rose-500/10 text-rose-400 border-rose-500/20");
      submitBtn.disabled = false;
      submitBtn.querySelector("span").textContent = oldText;
    }
  });

  function showFeedbackMsg(msg, classes) {
    authFeedback.textContent = msg;
    authFeedback.className = `p-4 rounded-xl text-xs font-semibold border ${classes}`;
    authFeedback.classList.remove("hidden");
  }

  function completeLogin(email) {
    localStorage.setItem("session_authenticated", "true");
    localStorage.setItem("session_email", email);

    showFeedbackMsg("Sucesso! Carregando infraestrutura...", "bg-teal-500/10 text-teal-400 border-teal-500/20");

    setTimeout(() => {
      document.body.classList.remove("not-logged-in");
      if (document.getElementById("auth-barrier")) {
        document.getElementById("auth-barrier").remove();
      }
      renderAuthUI(email);
      onSuccess();
    }, 1000);
  }
}

// INJETA COMPONENTES VISUAIS DA SESSÃO ATIVA (USER CARD E LOGOUT)
function renderAuthUI(email) {
  const truncatedEmail = email.length > 22 ? email.substring(0, 19) + "..." : email;
  const initial = email.substring(0, 2).toUpperCase();

  // 1) Procure na Sidebar (Desktop/Mobile)
  const sidebar = document.getElementById("sidebar");
  if (sidebar && !document.getElementById("sidebar-auth-user-card")) {
    const userContainer = document.createElement("div");
    userContainer.id = "sidebar-auth-user-card";
    userContainer.className = "mt-auto pt-4 border-t border-slate-800/80 mb-3 flex flex-col gap-2.5 shrink-0";
    userContainer.innerHTML = `
      <div class="flex items-center space-x-3 bg-slate-900/40 p-3 rounded-xl border border-slate-800">
        <div class="w-9 h-9 rounded-xl bg-[#00c2a8] text-slate-950 flex items-center justify-center font-bold text-xs uppercase shadow-md select-none shrink-0 font-space text-lg">
          ${initial}
        </div>
        <div class="flex-1 min-w-0">
          <p class="text-xs font-bold text-white truncate" title="${email}">${truncatedEmail}</p>
          <p class="text-[9px] text-[#00c2a8] font-bold tracking-wider uppercase">Sessão Ativa</p>
        </div>
      </div>
      <button id="btn-global-logout" class="flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl text-rose-400 hover:text-white bg-rose-500/5 hover:bg-rose-500/80 border border-rose-500/15 hover:border-rose-500/20 transition-all active:scale-95 font-semibold text-xs cursor-pointer w-full">
        <span>Sair do Sistema</span>
      </button>
    `;

    // Insira antes do rodapé de copyright da sidebar se houver
    const sidebarFooter = sidebar.querySelector(".mt-8.pt-6.border-t") || sidebar.querySelector("div:last-child");
    if (sidebarFooter && sidebarFooter !== sidebar) {
      sidebar.insertBefore(userContainer, sidebarFooter);
    } else {
      sidebar.appendChild(userContainer);
    }

    // Listener para o logout
    const logoutBtn = document.getElementById("btn-global-logout");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", () => triggerLogout());
    }
  }

  // 2) Se for na página index.html (Sem Sidebar, Portal Principal)
  const indexHeader = document.querySelector("header.relative.max-w-7xl");
  if (indexHeader && !document.getElementById("header-auth-badge")) {
    const indexUserBadge = document.createElement("div");
    indexUserBadge.id = "header-auth-badge";
    indexUserBadge.className = "flex items-center space-x-3 bg-slate-900/60 border border-slate-800 rounded-full pl-3.5 pr-1.5 py-1.5 text-xs text-slate-300 font-medium z-20 shadow-md ml-auto";
    indexUserBadge.innerHTML = `
      <div class="flex items-center space-x-2">
        <span class="w-2 h-2 rounded-full bg-[#00c2a8] animate-pulse"></span>
        <span class="font-bold text-white max-w-[200px] truncate" title="${email}">${truncatedEmail}</span>
      </div>
      <button id="btn-index-logout" class="px-3.5 py-1.5 bg-rose-500/10 hover:bg-rose-500 hover:text-white border border-rose-500/15 rounded-full text-[11px] font-bold text-rose-400 cursor-pointer transition flex items-center gap-1 active:scale-95 shadow-sm">
        <span>Sair</span>
      </button>
    `;

    // Se encontramos a caixinha "Ambiente de Produção Conectado", podemos adicioná-lo ao lado, ou substituir
    const prodBadge = indexHeader.querySelector(".text-teal-400.bg-slate-900\\/60");
    if (prodBadge) {
      prodBadge.before(indexUserBadge);
      // Remove o texto original de produção conectado em dispositivos menores para ficar limpo
      prodBadge.classList.add("hidden", "lg:flex");
    } else {
      indexHeader.appendChild(indexUserBadge);
    }

    const logoutBtnIndex = document.getElementById("btn-index-logout");
    if (logoutBtnIndex) {
      logoutBtnIndex.addEventListener("click", () => triggerLogout());
    }
  }
}

// REALIZA O LOGOUT DO SISTEMA COMPLETAMENTE
async function triggerLogout() {
  if (!confirm("Deseja realmente encerrar sua sessão no IntegraGest?")) return;

  try {
    const isMockEnv = !window.supabase || (typeof window.supabase.createClient === "undefined") || !import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY.startsWith("sb_publishable_");
    if (!isMockEnv && window.supabaseClient && window.supabaseClient.auth) {
      await window.supabaseClient.auth.signOut();
    }
  } catch (err) {
    console.warn("Erro ao deslogar no Supabase:", err);
  }

  localStorage.removeItem("session_authenticated");
  localStorage.removeItem("session_email");
  window.location.reload();
}

// Inicialização Geral da Página
document.addEventListener("DOMContentLoaded", () => {
  // 1) Solicitação de login na entrada antes de carregar qualquer coisa do sistema
  checkAuthentication(() => {
    // Inicializa ícones do Lucide
    if (window.lucide) {
      window.lucide.createIcons();
    }

    // Configura a navegação responsiva mobile (Sidebar Drawer)
    setupMobileNavigation();

    // Verifica se a chave do Supabase está disponível
    if (!SUPABASE_ANON_KEY) {
      console.warn("Chave pública VITE_SUPABASE_ANON_KEY não está preenchida. Carregando em Modo de Demonstração (Local).");
      const alertConfig = document.getElementById("supabase-alert-config");
      if (alertConfig) {
        alertConfig.classList.remove("hidden");
        const titleEl = alertConfig.querySelector("p.font-semibold");
        if (titleEl) {
          titleEl.textContent = "Modo de Demonstração Ativo (Off-line)";
        }
        const descEl = alertConfig.querySelector("p.text-xs");
        if (descEl) {
          descEl.innerHTML = 'A chave pública do Supabase não foi detectada. O sistema foi carregado no modo de demonstração local confiável. Quaisquer novos contratos ou lançamentos adicionados agora serão simulados e salvos localmente na memória do seu navegador (Local Storage). Adicione a variável <code class="bg-amber-100 px-1.5 py-0.5 rounded text-amber-900 border border-amber-300 font-mono text-[11px]">VITE_SUPABASE_ANON_KEY</code> no painel de segredos (Secrets) para conectar seu banco de dados na nuvem.';
        }
      }
      const mockDB = new MockSupabaseClient();
      supabaseClient = mockDB;
      supabase = mockDB;
      window.supabase = mockDB;
      window.supabaseClient = mockDB;
    } else {
      try {
        if (window.supabase) {
          const originalSDK = window.supabase;
          supabaseClient = originalSDK.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
          supabase = supabaseClient;
          
          // Crie um proxy ou junte as chaves no window.supabase para que tanto o SDK original .createClient quanto o cliente ativo continuem utilizáveis
          const combinedSupabase = Object.assign(supabaseClient, originalSDK);
          window.supabase = combinedSupabase;
          window.supabaseClient = supabaseClient;

          console.log("Supabase Client conectado com sucesso.");
        } else {
          console.error("SDK do Supabase não foi carregado corretamente via CDN.");
          // Fallback robusto de segurança se o script CDN falhar
          const mockDB = new MockSupabaseClient();
          supabaseClient = mockDB;
          supabase = mockDB;
        }
      } catch (err) {
        console.error("Erro ao inicializar conexão com Supabase. Carregando modo de backup.", err);
        const mockDB = new MockSupabaseClient();
        supabaseClient = mockDB;
        supabase = mockDB;
      }
    }

    // Carrega lógica baseada na tela atual detectando elementos ID do contêiner principal
    if (document.getElementById("dashboard-page")) {
      initDashboard();
    } else if (document.getElementById("contratos-page")) {
      initContratos();
    } else if (document.getElementById("financeiro-page")) {
      initFinanceiro();
    } else if (document.getElementById("custo-execucao-page")) {
      initCustoExecucaoPage();
    } else if (document.getElementById("documentos-page")) {
      initDocumentosPage();
    }
  });
});

// Hamburguer Menu Navigation Drawer
function setupMobileNavigation() {
  const toggleBtn = document.getElementById("mobile-menu-toggle");
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("sidebar-overlay");

  if (toggleBtn && sidebar && overlay) {
    const toggle = () => {
      sidebar.classList.toggle("-translate-x-full");
      overlay.classList.toggle("hidden");
    };

    toggleBtn.addEventListener("click", toggle);
    overlay.addEventListener("click", toggle);
  }
}

// ==========================================
// 1) LÓGICA DA TELA: DASHBOARD
// ==========================================
async function initDashboard() {
  const loading = document.getElementById("loading-state");
  const errorState = document.getElementById("error-state");
  const content = document.getElementById("content-grid");
  const errorMsg = document.getElementById("error-message");
  const refreshBtn = document.getElementById("btn-refresh");

  const loadData = async () => {
    if (!supabaseClient) {
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = "Supabase não configurado. Certifique-se de preencher a chave VITE_SUPABASE_ANON_KEY.";
      return;
    }

    loading.classList.remove("hidden");
    errorState.classList.add("hidden");
    content.classList.add("hidden");

    try {
      // Busca contratos, razão contábil e monitoramento mensal simultaneamente
      const [contractsRes, razaoRes, capexRes] = await Promise.all([
        supabaseClient.from("contratos").select("*"),
        supabaseClient.from("razao_2026").select("*"),
        supabaseClient.from("capex_monitoramento_mensal_").select("*")
      ]);

      if (contractsRes.error) throw contractsRes.error;
      if (razaoRes.error) throw razaoRes.error;
      if (capexRes.error) throw capexRes.error;

      const contracts = contractsRes.data || [];
      const razao = razaoRes.data || [];
      const capex = capexRes.data || [];
      
      const currentMonth = getMesAtual();
      const currentYear = new Date().getFullYear();
      const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
      const monthLabel = monthNames[currentMonth - 1] || "Junho";

      // 1) CUIDADO CUSTO DE EXECUÇÃO: Agrupa razão por código de projeto para cálculo exato de execução por contrato
      const acumuladoPorProjeto = {};
      razao.forEach(r => {
        const projCode = String(r.projeto || "").trim();
        const value = parseFloat(r.valor) || 0;
        if (projCode) {
          acumuladoPorProjeto[projCode] = (acumuladoPorProjeto[projCode] || 0) + value;
        }
      });

      // 2) CONVERSÃO DOS DADOS PARA REGRAS DE CARDS EXATOS:
      // - Total contratos e ativos
      let totalOrcado = 0;
      let totalExecutado = 0;
      let ativosCount = 0;
      let criticosCount = 0;

      contracts.forEach(c => {
        const codigo = String(c.codigo || "").trim();
        const orcado = parseFloat(c.capex_orcado) || 0;
        const executado = acumuladoPorProjeto[codigo] || 0;
        const percent = orcado > 0 ? (executado / orcado) * 100 : 0;

        totalOrcado += orcado;
        totalExecutado += executado;

        const normalStatus = String(c.status || "").toLowerCase().trim();
        if (normalStatus === "iniciado") {
          ativosCount++;
        }

        if (percent >= 90) {
          criticosCount++;
        }
      });

      const totalContratos = contracts.length;

      // Compute correct CAPEX metrics from capex_monitoramento_mensal_ table directly
      const capexOrcadoTotal_base = capex
        .filter(x => String(x.tipo || "").toLowerCase().trim() === "orçado" || String(x.tipo || "").toLowerCase().trim() === "orcado")
        .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);

      const capexRealizadoTotal_base = capex
        .filter(x => String(x.tipo || "").toLowerCase().trim() === "realizado")
        .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);

      const percentualExecucao_base = capexOrcadoTotal_base > 0 ? (capexRealizadoTotal_base / capexOrcadoTotal_base) * 100 : 0;

      // Renderização nos Cards do Dashboard
      document.getElementById("metric-total-contratos").textContent = totalContratos || "0";
      document.getElementById("metric-ativos-contratos").textContent = ativosCount || "0";
      document.getElementById("metric-capex-orcado").textContent = formatBRL(capexOrcadoTotal_base);
      document.getElementById("metric-capex-orcado").title = formatBRL(capexOrcadoTotal_base);
      document.getElementById("metric-capex-utilizado").textContent = formatBRL(capexRealizadoTotal_base);
      document.getElementById("metric-capex-utilizado").title = formatBRL(capexRealizadoTotal_base);
      document.getElementById("metric-percentual-exec").textContent = formatPercent(percentualExecucao_base);
      document.getElementById("metric-percentual-exec").title = formatPercent(percentualExecucao_base);
      
      const progressBar = document.getElementById("metric-exec-progress-bar");
      if (progressBar) {
        progressBar.style.width = `${Math.min(Math.max(percentualExecucao_base, 0), 100)}%`;
      }

      // 3) CARDS DE PLANEJAMENTO INTEGRADO DO OUTRO PLANO (PREVISTO / EXECUTADO ACUMULADOS ATÉ HOJE)
      const cardPrevisto = document.getElementById("metric-previsto-acumulado");
      if (cardPrevisto) {
        cardPrevisto.closest("article").querySelector("span.text-xs").textContent = `Previsto até ${monthLabel}`;
      }
      const cardRealizado = document.getElementById("metric-realizado-acumulado");
      if (cardRealizado) {
        cardRealizado.closest("article").querySelector("span.text-xs").textContent = `Executado até ${monthLabel}`;
      }

      // Previsto até o mês atual: soma de "Orçado" e mes <= currentMonth em capex_monitoramento_mensal_
      const acumuladoPrevistoMesAtual = capex
        .filter(x => (parseInt(x.ano) || 0) === currentYear && (parseInt(x.mes) || 0) <= currentMonth && (String(x.tipo || "").toLowerCase().trim() === "orçado" || String(x.tipo || "").toLowerCase().trim() === "orcado"))
        .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);

      // Realizado até o mês atual: soma razao_2026 até o mes atual
      const acumuladoRealizadoMesAtual = razao
        .filter(x => (parseInt(x.mes) || 0) <= currentMonth)
        .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);

      // Desvio (%) e Diferença
      const desvioAcumulado = acumuladoPrevistoMesAtual > 0 
        ? ((acumuladoRealizadoMesAtual - acumuladoPrevistoMesAtual) / acumuladoPrevistoMesAtual) * 100 
        : 0;

      if (cardPrevisto) cardPrevisto.textContent = formatBRL(acumuladoPrevistoMesAtual);
      if (cardRealizado) cardRealizado.textContent = formatBRL(acumuladoRealizadoMesAtual);

      const desvioEl = document.getElementById("metric-desvio-acumulado");
      const desvioBg = document.getElementById("id-desvio-bg");
      if (desvioEl && desvioBg) {
        desvioEl.textContent = (desvioAcumulado > 0 ? "+" : "") + formatPercent(desvioAcumulado);
        if (desvioAcumulado > 0) {
          desvioEl.className = "text-xl md:text-2xl font-bold font-space text-rose-600 truncate block font-bold";
          desvioBg.className = "p-2 bg-rose-50 rounded-lg text-rose-500";
        } else {
          desvioEl.className = "text-xl md:text-2xl font-bold font-space text-emerald-600 truncate block font-bold";
          desvioBg.className = "p-2 bg-teal-50 rounded-lg text-emerald-500";
        }
      }

      // Card 9: Quantidade de Contratos Críticos
      const criticosBadge = document.getElementById("metric-contratos-criticos");
      if (criticosBadge) {
        criticosBadge.textContent = criticosCount;
      }

      // 4) PREENCHE INDICADORES AGREGADOS SIMPLES DE EXECUÇÃO:
      let topProjCode = "";
      let topProjValor = 0;
      for (const [code, val] of Object.entries(acumuladoPorProjeto)) {
        if (val > topProjValor) {
          topProjValor = val;
          topProjCode = code;
        }
      }
      const topContractObj = contracts.find(c => String(c.codigo || "").trim() === topProjCode);
      const topContractName = topContractObj ? topContractObj.nome : topProjCode || "Sem Lançamentos";

      const topContractEl = document.getElementById("indicator-top-contrato");
      if (topContractEl) {
        topContractEl.textContent = topContractName;
        topContractEl.title = topContractName;
      }
      const topValueEl = document.getElementById("indicator-top-contrato-valor");
      if (topValueEl) {
        topValueEl.textContent = formatBRL(topProjValor);
      }
      const totalConciliadoEl = document.getElementById("indicator-total-conciliado");
      if (totalConciliadoEl) {
        totalConciliadoEl.textContent = formatBRL(totalExecutado);
      }

      // 5) COMPARAÇÃO MENSAL: Tabela de fluxo mensal discreto por mês
      const comparacaoTbody = document.querySelector("#tabelaComparacaoMensal tbody");
      if (comparacaoTbody) {
        comparacaoTbody.innerHTML = "";
        for (let m = 1; m <= 12; m++) {
          const prevM = capex
            .filter(x => (parseInt(x.ano) || 0) === currentYear && (parseInt(x.mes) || 0) === m && (String(x.tipo || "").toLowerCase().trim() === "orçado" || String(x.tipo || "").toLowerCase().trim() === "orcado"))
            .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);
          
          const realM = m <= currentMonth ? razao
            .filter(x => (parseInt(x.mes) || 0) === m)
            .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0) : 0;
          
          const diferenca = realM - prevM;
          const diffColor = diferenca > 0 ? "text-rose-600 font-semibold" : (diferenca < 0 ? "text-emerald-600" : "text-slate-400");
          const formatDiff = (diferenca > 0 ? "+" : "") + formatBRL(diferenca);

          const tr = document.createElement("tr");
          tr.className = "hover:bg-slate-50/50 transition border-b border-slate-100 text-[11px] font-medium";
          tr.innerHTML = `
            <td class="py-2.5 px-3 font-semibold text-slate-600">${monthNames[m - 1]}</td>
            <td class="py-2.5 px-3 text-right font-mono text-slate-500">${formatBRL(prevM)}</td>
            <td class="py-2.5 px-3 text-right font-mono text-[#0b1f3a] font-semibold">${m <= currentMonth ? formatBRL(realM) : "-"}</td>
            <td class="py-2.5 px-3 text-right font-mono ${diffColor}">${m <= currentMonth ? formatDiff : "-"}</td>
          `;
          comparacaoTbody.appendChild(tr);
        }
      }

      // 6) CURVA S ACCUMULATIVE CALCULATION:
      const labelsS = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
      const sCurvePrevisto = [];
      const sCurveRealizado = [];
      let accumPrev = 0;
      let accumReal = 0;

      for (let m = 1; m <= 12; m++) {
        const prevM = capex
          .filter(x => (parseInt(x.ano) || 0) === currentYear && (parseInt(x.mes) || 0) === m && (String(x.tipo || "").toLowerCase().trim() === "orçado" || String(x.tipo || "").toLowerCase().trim() === "orcado"))
          .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);
        accumPrev += prevM;
        sCurvePrevisto.push(accumPrev);

        if (m <= currentMonth) {
          const realM = razao
            .filter(x => (parseInt(x.mes) || 0) === m)
            .reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);
          accumReal += realM;
          sCurveRealizado.push(accumReal);
        } else {
          sCurveRealizado.push(null); // Evita queda abrupta do gráfico de linha para zero
        }
      }

      // Desenha a magnífica curva S line chart medindo previsão real do banco de dados
      renderSCurveChartDashboard(labelsS, sCurvePrevisto, sCurveRealizado);

      loading.classList.add("hidden");
      content.classList.remove("hidden");
    } catch (err) {
      console.error("Erro ao carregar dados do Dashboard:", err);
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = `Falha ao processar dados de planejamento e curva S: ${err.message || err}`;
    }
  };

  if (refreshBtn) {
    refreshBtn.addEventListener("click", loadData);
  }

  loadData();
}

function renderSCurveChartDashboard(labels, previsto, realizado) {
  const ctx = document.getElementById("sCurveChart").getContext("2d");

  if (window.instanceSCurveChart) {
    window.instanceSCurveChart.destroy();
  }

  window.instanceSCurveChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Previsto Acumulado (CAPEX)",
          data: previsto,
          borderColor: "rgba(11, 31, 58, 0.45)",
          borderWidth: 2,
          borderDash: [5, 5],
          backgroundColor: "rgba(11, 31, 58, 0.02)",
          fill: true,
          tension: 0.25,
          pointRadius: 3,
          pointBackgroundColor: "rgba(11, 31, 58, 0.6)"
        },
        {
          label: "Realizado Acumulado (Razão)",
          data: realizado,
          borderColor: "#00c2a8",
          borderWidth: 3,
          backgroundColor: "rgba(0, 194, 168, 0.08)",
          fill: true,
          tension: 0.25,
          pointRadius: 4,
          pointBackgroundColor: "#00c2a8",
          pointHoverRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: "top",
          labels: {
            boxWidth: 15,
            padding: 15,
            font: { family: "Inter", size: 11, weight: "500" },
            color: "#64748b"
          }
        },
        tooltip: {
          padding: 12,
          cornerRadius: 10,
          backgroundColor: "#0b1f3a",
          titleFont: { family: "Space Grotesk", size: 12, weight: "bold" },
          bodyFont: { family: "Inter", size: 11 },
          callbacks: {
            label: function (context) {
              const label = context.dataset.label ? context.dataset.label.split(" ")[0] : "";
              const val = context.parsed.y || 0;
              return ` ${label} Acumulado: ${formatBRL(val)}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { family: "Inter", size: 10 }, color: "#64748b" }
        },
        y: {
          grid: { color: "rgba(148, 163, 184, 0.15)" },
          ticks: {
            font: { family: "Inter", size: 10 },
            color: "#64748b",
            callback: function (value) {
              if (value >= 1000000) {
                return "R$ " + (value / 1000000).toFixed(1) + "M";
              }
              if (value >= 1000) {
                return "R$ " + (value / 1000).toFixed(0) + "k";
              }
              return "R$ " + value;
            }
          }
        }
      }
    }
  });
}

// ==========================================
// 2) LÓGICA DA TELA: CONTRATOS
// ==========================================
async function initContratos() {
  const loading = document.getElementById("loading-state");
  const errorState = document.getElementById("error-state");
  const content = document.getElementById("content-area");
  const errorMsg = document.getElementById("error-message");
  const refreshBtn = document.getElementById("btn-refresh");
  const tableBody = document.getElementById("contracts-table-body");
  const searchInput = document.getElementById("search-input");
  const statusFilter = document.getElementById("status-filter");
  const emptySearch = document.getElementById("empty-search-state");

  // Form elements for Novo Contrato
  const toggleFormBtn = document.getElementById("toggle-form-btn");
  const formContainer = document.getElementById("new-contract-form-container");
  const formChevron = document.getElementById("form-chevron");
  const formEl = document.getElementById("new-contract-form");
  const formFeedback = document.getElementById("form-feedback");

  let allContracts = [];

  // Toggle form visibility
  if (toggleFormBtn && formContainer) {
    toggleFormBtn.addEventListener("click", () => {
      formContainer.classList.toggle("hidden");
      if (formChevron) {
        formChevron.classList.toggle("rotate-180");
      }
    });
  }

  // Submit handler for new contract
  if (formEl) {
    formEl.addEventListener("submit", async (e) => {
      e.preventDefault();
      
      const codigo = document.getElementById("form-codigo").value.trim();
      const nome = document.getElementById("form-nome").value.trim();
      const status = document.getElementById("form-status").value;
      const capex_orcado = parseFloat(document.getElementById("form-capex-orcado").value);

      if (!codigo || !nome || isNaN(capex_orcado)) {
        showFeedback("Preencha todos os campos obrigatórios.", "error");
        return;
      }

      showFeedback("Salvando novo contrato...", "loading");

      try {
        const { error } = await supabaseClient
          .from("contratos")
          .insert([{ 
            codigo, 
            nome, 
            status, 
            capex_orcado: parseFloat(capex_orcado) || 0,
            capex_utilizado: 0 
          }]);

        if (error) throw error;

        showFeedback("Contrato cadastrado com sucesso!", "success");
        formEl.reset();

        // Refresh dynamic table data
        await loadData();

        setTimeout(() => {
          formContainer.classList.add("hidden");
          if (formChevron) formChevron.classList.remove("rotate-180");
          if (formFeedback) formFeedback.classList.add("hidden");
        }, 1500);

      } catch (err) {
        console.error("Erro ao cadastrar contrato:", err);
        showFeedback(`Erro ao salvar: ${err.message || err}`, "error");
      }
    });
  }

  function showFeedback(msg, type) {
    if (!formFeedback) return;
    formFeedback.classList.remove("hidden", "bg-red-50", "text-red-700", "bg-teal-50", "text-teal-700", "bg-blue-50", "text-blue-700");
    formFeedback.textContent = msg;

    if (type === "error") {
      formFeedback.classList.add("bg-red-50", "text-red-700", "p-3", "rounded-xl", "text-xs");
    } else if (type === "success") {
      formFeedback.classList.add("bg-teal-50", "text-teal-700", "p-3", "rounded-xl", "text-xs");
    } else {
      formFeedback.classList.add("bg-blue-50", "text-blue-700", "p-3", "rounded-xl", "text-xs");
    }
  }

  const renderTable = (contracts) => {
    tableBody.innerHTML = "";
    
    if (contracts.length === 0) {
      emptySearch.classList.remove("hidden");
      return;
    }
    emptySearch.classList.add("hidden");

    contracts.forEach(item => {
      const pct = parseFloat(item.percentual_execucao) || 0;
      const clampedPct = Math.min(Math.max(pct, 0), 100);

      // Determinação das classes semânticas de acordo com as faixas de execução financeira
      let progressColorClass = "bg-[#00c2a8]";
      let badgeStyleClass = "bg-teal-50 text-teal-700 border-teal-200";

      if (pct >= 95) {
        progressColorClass = "bg-rose-500";
        badgeStyleClass = "bg-red-50 text-red-600 border-red-200";
      } else if (pct >= 80) {
        progressColorClass = "bg-amber-500";
        badgeStyleClass = "bg-amber-50 text-amber-600 border-amber-200";
      } else {
        progressColorClass = "bg-[#00c2a8]";
        badgeStyleClass = "bg-teal-50 text-teal-600 border-teal-100";
      }

      // Trata amigavelmente o status corporativo
      let statusClass = "bg-slate-100 text-slate-700 border-slate-200";
      let statusNome = item.status || "Indefinido";

      const normalStatus = String(item.status || "").toLowerCase().trim();
      if (normalStatus.includes("ativo") || normalStatus.includes("ativa") || normalStatus.includes("execucao") || normalStatus.includes("execução") || normalStatus.includes("andamento") || normalStatus.includes("vigente") || normalStatus.includes("vigência") || normalStatus.includes("vigencia") || normalStatus.includes("vigor") || normalStatus.includes("assinado") || normalStatus.includes("em aberto") || normalStatus.includes("aprovado") || normalStatus.includes("iniciado")) {
        statusClass = "bg-emerald-50 text-emerald-700 border-emerald-100";
      } else if (normalStatus.includes("concluid") || normalStatus.includes("finaliz")) {
        statusClass = "bg-blue-50 text-blue-700 border-blue-100";
      } else if (normalStatus.includes("analis") || normalStatus.includes("pendent")) {
        statusClass = "bg-amber-50 text-amber-700 border-amber-100";
      }

      // Check if Not Started (Não Iniciado)
      const isNaoIniciado = normalStatus === "não iniciado" || normalStatus === "nao iniciado" || normalStatus.includes("não") || normalStatus.includes("nao");

      const row = document.createElement("tr");
      row.className = "hover:bg-slate-50/80 transition duration-150";
      row.innerHTML = `
        <td class="py-4 px-6 font-mono text-xs font-bold text-slate-500">${item.codigo || "-"}</td>
        <td class="py-4 px-6">
          <div class="font-semibold text-slate-800">${item.nome || "Contrato Sem Nome"}</div>
          <div class="text-[11px] text-slate-400 mt-0.5">Identificador Contratual</div>
        </td>
        <td class="py-4 px-6">
          <span class="px-2.5 py-1 text-xs font-medium rounded-full border ${statusClass}">
            ${statusNome}
          </span>
        </td>
        <td class="py-4 px-6 text-right font-medium text-slate-700">${formatBRL(item.capex_orcado)}</td>
        <td class="py-4 px-6 text-right font-medium text-emerald-600">${formatBRL(item.capex_utilizado)}</td>
        <td class="py-4 px-6 text-right font-medium text-slate-500">${formatBRL(item.saldo_capex)}</td>
        <td class="py-4 px-6">
          <div class="flex items-center space-x-3 justify-end sm:justify-center">
            <div class="w-24 bg-slate-100 rounded-full h-1.5 overflow-hidden hidden xl:block shrink-0">
              <div class="h-full rounded-full ${progressColorClass} transition-all duration-700" style="width: ${clampedPct}%"></div>
            </div>
            <span class="px-2 py-0.5 text-xs font-bold rounded-lg border shrink-0 ${badgeStyleClass}">
              ${formatPercent(pct)}
            </span>
          </div>
        </td>
        <td class="py-4 px-6 text-center">
          ${item.arquivo_contrato ? `
            <div class="flex items-center justify-center space-x-1.5">
              <a href="${item.arquivo_contrato}" target="_blank" class="text-teal-600 hover:text-white hover:bg-teal-500 border border-teal-200 px-2 py-1 rounded text-xs font-bold transition flex items-center gap-1 shadow-sm bg-teal-50/40">
                <i data-lucide="file-text" class="w-3.5 h-3.5"></i>
                <span>Visualizar</span>
              </a>
              <button class="btn-delete-arq text-rose-500 hover:text-white hover:bg-rose-500 border border-rose-200 p-1.5 rounded-lg transition hover:scale-105 active:scale-95" data-codigo="${item.codigo}" title="Remover Documento">
                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
              </button>
            </div>
          ` : `
            <div class="flex items-center justify-center">
              <label class="cursor-pointer bg-slate-100 hover:bg-teal-50 hover:text-teal-700 text-slate-500 border border-slate-200 hover:border-teal-300 px-2.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 active:scale-95">
                <i data-lucide="upload-cloud" class="w-3.5 h-3.5 text-slate-400"></i>
                <span>Anexar PDF</span>
                <input type="file" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg" class="hidden input-upload-contrato" data-codigo="${item.codigo}">
              </label>
            </div>
          `}
        </td>
        <td class="py-4 px-6 text-center">
          <div class="flex items-center justify-center">
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" class="sr-only peer toggle-liberar-capex" data-codigo="${item.codigo}" ${item.liberar_leitura_capex !== false ? "checked" : ""}>
              <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-500"></div>
            </label>
          </div>
        </td>
        <td class="py-4 px-6 text-center">
          ${isNaoIniciado ? `
            <button class="btn-iniciar bg-teal-500 hover:bg-teal-600 text-white font-bold text-[11px] px-3 py-1.5 rounded-xl shadow-sm transition active:scale-95 inline-flex items-center space-x-1" data-codigo="${item.codigo}">
              <i data-lucide="play" class="w-3.5 h-3.5"></i>
              <span>Iniciar</span>
            </button>
          ` : `
            <span class="text-xs text-slate-400 font-medium flex items-center justify-center">
              <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-500 mr-1 shrink-0"></i>
              Sim
            </span>
          `}
        </td>
      `;
      tableBody.appendChild(row);
    });

    // Attach click listeners to "Iniciar" buttons
    tableBody.querySelectorAll(".btn-iniciar").forEach(btn => {
      btn.addEventListener("click", async () => {
        const codigo = btn.getAttribute("data-codigo");
        
        btn.disabled = true;
        btn.innerHTML = `<span class="inline-block w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>`;

        try {
          const { error } = await supabaseClient
            .from("contratos")
            .update({ status: "Iniciado" })
            .eq("codigo", codigo);

          if (error) throw error;

          console.log(`Contrato ${codigo} iniciado com sucesso.`);
          await loadData();
          
        } catch (err) {
          console.error("Erro ao iniciar contrato:", err);
          alert(`Falha ao iniciar contrato: ${err.message || err}`);
          btn.disabled = false;
          btn.innerHTML = `<i data-lucide="play" class="w-3.5 h-3.5"></i><span>Iniciar</span>`;
          if (window.lucide) {
            window.lucide.createIcons();
          }
        }
      });
    });

    // Ouvinte para upload de arquivos de contratos no bucket 'contratos_'
    tableBody.querySelectorAll(".input-upload-contrato").forEach(input => {
      input.addEventListener("change", async (e) => {
        const codigo = input.getAttribute("data-codigo");
        const file = e.target.files[0];
        if (!file) return;

        const label = input.parentElement;
        const originalHTML = label.innerHTML;
        label.innerHTML = `<span class="inline-block w-3.5 h-3.5 border-2 border-teal-500/30 border-t-teal-500 rounded-full animate-spin"></span><span class="text-[10px] text-slate-400 font-bold ml-1">Carregando...</span>`;

        try {
          let fileUrl = "";

          try {
            if (supabaseClient && supabaseClient.storage && !supabaseClient.isMock) {
              const pathName = `ctr_${codigo}_${Date.now()}_${file.name}`;
              const { data, error } = await supabaseClient.storage
                .from("contratos_")
                .upload(pathName, file);

              if (!error && data) {
                const { data: pubData } = supabaseClient.storage.from("contratos_").getPublicUrl(pathName);
                fileUrl = pubData.publicUrl;
              }
            }
          } catch (storageErr) {
            console.warn("Storage do Supabase inacessível, utilizando fallback Base64.", storageErr);
          }

          if (!fileUrl) {
            fileUrl = await fileToBase64(file);
          }

          const { error } = await supabaseClient
            .from("contratos")
            .update({ arquivo_contrato: fileUrl })
            .eq("codigo", codigo);

          if (error) throw error;

          console.log(`Arquivo anexado ao contrato ${codigo} com sucesso.`);
          await loadData();
        } catch (err) {
          console.error("Erro ao subir arquivo:", err);
          alert(`Falha ao processar arquivo: ${err.message || err}`);
          label.innerHTML = originalHTML;
        }
      });
    });

    // Ouvinte para remover documento do contrato
    tableBody.querySelectorAll(".btn-delete-arq").forEach(btn => {
      btn.addEventListener("click", async () => {
        const codigo = btn.getAttribute("data-codigo");
        if (!confirm("Deseja realmente remover o arquivo anexo deste contrato?")) return;

        btn.disabled = true;
        const originalHTML = btn.innerHTML;
        btn.innerHTML = `<span class="inline-block w-3.5 h-3.5 border-2 border-rose-500/30 border-t-rose-500 rounded-full animate-spin"></span>`;

        try {
          // Tenta remover o arquivo físico do storage se existir
          const contractItem = allContracts.find(c => String(c.codigo).trim() === String(codigo).trim());
          const fileUrl = contractItem ? contractItem.arquivo_contrato : null;

          if (fileUrl && fileUrl.includes("/contratos_/")) {
            try {
              const parts = fileUrl.split("/contratos_/");
              if (parts.length > 1) {
                const pathName = decodeURIComponent(parts[1]);
                if (supabaseClient && supabaseClient.storage && !supabaseClient.isMock) {
                  await supabaseClient.storage.from("contratos_").remove([pathName]);
                  console.log("Arquivo físico deletado do bucket contratos_:", pathName);
                }
              }
            } catch (storageErr) {
              console.warn("Erro ao deletar arquivo físico do bucket:", storageErr);
            }
          }

          const { error } = await supabaseClient
            .from("contratos")
            .update({ arquivo_contrato: null })
            .eq("codigo", codigo);

          if (error) throw error;

          console.log(`Arquivo do contrato ${codigo} removido.`);
          await loadData();
        } catch (err) {
          console.error("Erro ao remover documento:", err);
          alert(`Falha ao remover documento: ${err.message || err}`);
          btn.disabled = false;
          btn.innerHTML = originalHTML;
        }
      });
    });

    // Ouvinte para alternar permissão liberar_leitura_capex
    tableBody.querySelectorAll(".toggle-liberar-capex").forEach(toggle => {
      toggle.addEventListener("change", async () => {
        const codigo = toggle.getAttribute("data-codigo");
        const checked = toggle.checked;

        try {
          const { error } = await supabaseClient
            .from("contratos")
            .update({ liberar_leitura_capex: checked })
            .eq("codigo", codigo);

          if (error) throw error;
          console.log(`Permissão liberar_leitura_capex atualizada para ${checked} no contrato ${codigo}`);
        } catch (err) {
          console.error("Erro ao salvar permissão:", err);
          alert(`Erro ao salvar permissão: ${err.message || err}`);
          toggle.checked = !checked; // reverte estado visual
        }
      });
    });

    if (window.lucide) {
      window.lucide.createIcons();
    }
  };

  const applyFilters = () => {
    const query = searchInput.value.toLowerCase().trim();
    const statusVal = statusFilter.value;

    const filtered = allContracts.filter(c => {
      const matchSearch = String(c.nome || "").toLowerCase().includes(query) || 
                          String(c.codigo || "").toLowerCase().includes(query);
      
      if (!matchSearch) return false;

      if (statusVal === "all") return true;
      const cStatus = String(c.status || "").toLowerCase().trim();
      
      if (statusVal === "active") {
        return cStatus === "iniciado";
      }
      if (statusVal === "concluded") {
        return cStatus.includes("concluid") || cStatus.includes("finaliz");
      }
      if (statusVal === "pending") {
        const isAct = cStatus === "iniciado";
        const isCon = cStatus.includes("concluid") || cStatus.includes("finaliz");
        return cStatus.includes("analis") || cStatus.includes("pendent") || (!isAct && !isCon);
      }

      return true;
    });

    renderTable(filtered);
    document.getElementById("contracts-summary-count").textContent = filtered.length;
  };

  const loadData = async () => {
    if (!supabaseClient) {
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = "Supabase não configurado. Certifique-se de preencher a chave VITE_SUPABASE_ANON_KEY para realizar a consulta de dados.";
      return;
    }

    loading.classList.remove("hidden");
    errorState.classList.add("hidden");
    content.classList.add("hidden");

    try {
      // Consumo exclusivo da view capex_por_contrato
      const { data, error } = await supabaseClient
        .from("capex_por_contrato")
        .select("*")
        .order("codigo", { ascending: true });

      if (error) throw error;

      allContracts = data || [];
      renderTable(allContracts);
      
      // Calculate top indicators for contratos.html
      const totalContratos = allContracts.length;
      const totalOrcado = allContracts.reduce((acc, curr) => acc + (parseFloat(curr.capex_orcado) || 0), 0);
      const totalExecutado = allContracts.reduce((acc, curr) => acc + (parseFloat(curr.capex_utilizado) || 0), 0);
      const percentualExecGeral = totalOrcado > 0 ? (totalExecutado / totalOrcado) * 100 : 0;

      const metricTotalEl = document.getElementById("contracts-metric-total");
      const metricOrcadoEl = document.getElementById("contracts-metric-orcado");
      const metricExecutadoEl = document.getElementById("contracts-metric-executado");
      const metricPercentEl = document.getElementById("contracts-metric-percent");
      const metricPercentBarEl = document.getElementById("contracts-metric-percent-bar");

      if (metricTotalEl) metricTotalEl.textContent = totalContratos;
      if (metricOrcadoEl) metricOrcadoEl.textContent = formatBRL(totalOrcado);
      if (metricExecutadoEl) metricExecutadoEl.textContent = formatBRL(totalExecutado);
      if (metricPercentEl) metricPercentEl.textContent = formatPercent(percentualExecGeral);
      if (metricPercentBarEl) {
        metricPercentBarEl.style.width = `${Math.min(Math.max(percentualExecGeral, 0), 100)}%`;
      }

      document.getElementById("contracts-summary-count").textContent = allContracts.length;

      loading.classList.add("hidden");
      content.classList.remove("hidden");
    } catch (err) {
      console.error("Erro ao carregar contratos:", err);
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = `Falha ao importar dados da view 'capex_por_contrato'. Detalhes: ${err.message || err}`;
    }
  };

  // Eventos de filtro em tempo real
  if (searchInput) searchInput.addEventListener("input", applyFilters);
  if (statusFilter) statusFilter.addEventListener("change", applyFilters);
  if (refreshBtn) refreshBtn.addEventListener("click", loadData);

  loadData();
}

// ==========================================
// 3) LÓGICA DA TELA: ACOMPANHAMENTO MENSAL
// ==========================================
async function initFinanceiro() {
  const loading = document.getElementById("loading-state");
  const errorState = document.getElementById("error-state");
  const content = document.getElementById("content-grid");
  const errorMsg = document.getElementById("error-message");
  const refreshBtn = document.getElementById("btn-refresh");
  const tableBody = document.getElementById("financial-table-body");
  const yearFilter = document.getElementById("year-filter");
  const projectFilter = document.getElementById("project-filter");
  const cityFilter = document.getElementById("city-filter");

  // Form elements for CAPEX Launch
  const toggleFinanceBtn = document.getElementById("toggle-finance-btn");
  const financeFormContainer = document.getElementById("finance-form-container");
  const financeChevron = document.getElementById("finance-chevron");
  const newFinanceForm = document.getElementById("new-finance-form");
  const financeFormFeedback = document.getElementById("finance-form-feedback");

  let rawFinancialRecords = [];

  const monthNames = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ];

  // Toggle form visibility
  if (toggleFinanceBtn && financeFormContainer) {
    toggleFinanceBtn.addEventListener("click", () => {
      financeFormContainer.classList.toggle("hidden");
      if (financeChevron) {
        financeChevron.classList.toggle("rotate-180");
      }
    });
  }

  // Handle new CAPEX submit
  if (newFinanceForm) {
    newFinanceForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const ano = parseInt(document.getElementById("finance-ano").value);
      const mes = parseInt(document.getElementById("finance-mes").value);
      const indicador = document.getElementById("finance-indicador").value.trim();
      const tipo = document.getElementById("finance-tipo").value;
      const valor = parseFloat(document.getElementById("finance-valor").value);

      if (isNaN(ano) || isNaN(mes) || !indicador || !tipo || isNaN(valor)) {
        showFinanceFeedback("Preencha todos os campos obrigatórios corretamente.", "error");
        return;
      }

      const mes_nome = monthNames[mes - 1];

      showFinanceFeedback("Lançando CAPEX...", "loading");

      try {
        const { error } = await supabaseClient
          .from("capex_monitoramento_mensal_")
          .insert([{ ano, mes, mes_nome, indicador, tipo, valor }]);

        if (error) throw error;

        showFinanceFeedback("Lançamento de CAPEX inserido com sucesso!", "success");
        newFinanceForm.reset();

        // Refresh database and recreate graphics & table automatically
        await loadData();

        setTimeout(() => {
          financeFormContainer.classList.add("hidden");
          if (financeChevron) financeChevron.classList.remove("rotate-180");
          if (financeFormFeedback) financeFormFeedback.classList.add("hidden");
        }, 1500);

      } catch (err) {
        console.error("Erro ao lançar CAPEX:", err);
        showFinanceFeedback(`Erro ao salvar: ${err.message || err}`, "error");
      }
    });
  }

  function showFinanceFeedback(msg, type) {
    if (!financeFormFeedback) return;
    financeFormFeedback.classList.remove("hidden", "bg-red-50", "text-red-700", "bg-teal-50", "text-teal-700", "bg-blue-50", "text-blue-700");
    financeFormFeedback.textContent = msg;

    if (type === "error") {
      financeFormFeedback.classList.add("bg-red-50", "text-red-700", "p-3", "rounded-xl", "text-xs");
    } else if (type === "success") {
      financeFormFeedback.classList.add("bg-teal-50", "text-teal-700", "p-3", "rounded-xl", "text-xs");
    } else {
      financeFormFeedback.classList.add("bg-blue-50", "text-blue-700", "p-3", "rounded-xl", "text-xs");
    }
  }

  const aggregateAndProcess = () => {
    const selectedYear = yearFilter.value;
    const selectedProject = projectFilter ? projectFilter.value : "all";
    const selectedCity = cityFilter ? cityFilter.value : "all";
    
    // Filtra pelo ano, projeto e cidade se necessário
    let filteredRecords = rawFinancialRecords;
    if (selectedYear !== "all") {
      filteredRecords = filteredRecords.filter(item => String(item.ano) === selectedYear);
    }
    if (selectedProject !== "all") {
      filteredRecords = filteredRecords.filter(item => String(item.indicador || "").trim() === selectedProject);
    }
    if (selectedCity !== "all") {
      filteredRecords = filteredRecords.filter(item => {
        const indicadorText = String(item.indicador || "").toLowerCase();
        return indicadorText.includes(selectedCity.toLowerCase());
      });
    }

    // Agrupar e somar por competência (ano, mês e nome_mês)
    const monthlyGroups = {};

    filteredRecords.forEach(item => {
      // Cria chave única anualizada para ordenação correta das competências cronológicas
      const key = `${item.ano}-${String(item.mes).padStart(2, "0")}`;
      if (!monthlyGroups[key]) {
        let rawMesNome = String(item.mes_nome || "").trim();
        const mes_nome = rawMesNome.toLowerCase() === "marco" ? "Março" : rawMesNome;
        monthlyGroups[key] = {
          ano: item.ano,
          mes: item.mes,
          mes_nome: mes_nome,
          orcado: 0,
          realizado: 0
        };
      }

      const val = parseFloat(item.valor) || 0;
      const normalizedTipo = String(item.tipo || "").trim().toLowerCase();
      if (normalizedTipo.includes("orc") || normalizedTipo.includes("orç")) {
        monthlyGroups[key].orcado += val;
      } else if (normalizedTipo.includes("real")) {
        monthlyGroups[key].realizado += val;
      }
    });

    // Converte para vetor ordenado pelo ano/mês
    const sortedMonths = Object.keys(monthlyGroups)
      .sort()
      .map(k => monthlyGroups[k]);

    // Calcula Acumulado de Curva S
    let runningOrcado = 0;
    let runningRealizado = 0;

    const dataLabels = [];
    const arrOrcado = [];
    const arrRealizado = [];
    const arrS_Orcado = [];
    const arrS_Realizado = [];

    tableBody.innerHTML = "";

    sortedMonths.forEach(m => {
      runningOrcado += m.orcado;
      runningRealizado += m.realizado;

      // Guarda referências para gráficos
      const labelComp = `${m.mes_nome}/${String(m.ano)}`;
      dataLabels.push(labelComp);
      arrOrcado.push(m.orcado);
      arrRealizado.push(m.realizado);
      arrS_Orcado.push(runningOrcado);
      arrS_Realizado.push(runningRealizado);

      // Preenche tabela descritiva complementar
      const saldoMes = m.orcado - m.realizado;
      const rateExec = m.orcado > 0 ? (m.realizado / m.orcado) * 100 : 0;

      let badgeClass = "bg-teal-50 text-teal-700 border-teal-100";
      if (rateExec >= 105 || rateExec < 35) {
        badgeClass = "bg-red-50 text-red-600 border-red-100";
      } else if (rateExec >= 90) {
        badgeClass = "bg-amber-50 text-amber-600 border-amber-100";
      }

      const tr = document.createElement("tr");
      tr.className = "hover:bg-slate-50/80 transition duration-150";
      tr.innerHTML = `
        <td class="py-4 px-6">
          <div class="font-bold text-[#0b1f3a]">${m.mes_nome}</div>
          <div class="text-[10px] text-slate-400 font-medium">Ano Fiscal ${m.ano}</div>
        </td>
        <td class="py-4 px-6 text-right font-medium text-slate-700">${formatBRL(m.orcado)}</td>
        <td class="py-4 px-6 text-right font-medium text-emerald-600">${formatBRL(m.realizado)}</td>
        <td class="py-4 px-6 text-right font-medium ${saldoMes < 0 ? 'text-rose-600' : 'text-slate-500'}">${formatBRL(saldoMes)}</td>
        <td class="py-4 px-6 text-center">
          <span class="px-2.5 py-0.5 text-xs font-bold rounded-lg border ${badgeClass}">
            ${formatPercent(rateExec)}
          </span>
        </td>
      `;
      tableBody.appendChild(tr);
    });

    // Renderiza Gráficos ChartJS com dados processados
    renderBarChart(dataLabels, arrOrcado, arrRealizado);
    renderSCurveChart(dataLabels, arrS_Orcado, arrS_Realizado);
  };

  const loadData = async () => {
    if (!supabaseClient) {
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = "Supabase não configurado. Certifique-se de preencher a chave VITE_SUPABASE_ANON_KEY para realizar a consulta de dados.";
      return;
    }

    loading.classList.remove("hidden");
    errorState.classList.add("hidden");
    content.classList.add("hidden");

    try {
      // Consumo exclusivo da tabela capex_monitoramento_mensal_ ordenada corretamente
      const { data, error } = await supabaseClient
        .from("capex_monitoramento_mensal_")
        .select("*")
        .order("ano", { ascending: true })
        .order("mes", { ascending: true });

      if (error) throw error;

      rawFinancialRecords = data || [];

      // Popula o select do formulário de lançamento com os contratos reais cadastrados no sistema
      try {
        const { data: contractsRes } = await supabaseClient
          .from("contratos")
          .select("codigo, nome")
          .order("codigo", { ascending: true });
        
        const financeIndicadorSelect = document.getElementById("finance-indicador");
        if (financeIndicadorSelect) {
          const prevVal = financeIndicadorSelect.value;
          financeIndicadorSelect.innerHTML = '<option value="">Selecione o Contrato/Projeto...</option>';
          if (contractsRes && contractsRes.length > 0) {
            contractsRes.forEach(c => {
              const opt = document.createElement("option");
              opt.value = c.nome; // O valor enviado como indicador é o nome do contrato pois é por ele que o join é feito
              opt.textContent = `${c.codigo} - ${c.nome}`;
              financeIndicadorSelect.appendChild(opt);
            });
          }
          if (prevVal) {
            financeIndicadorSelect.value = prevVal;
          }
        }
      } catch (contractsErr) {
        console.warn("Falha ao buscar contratos para o seletor de lançamento de CAPEX:", contractsErr);
      }

      // Popula o filtro de projetos/indicador de forma dinâmica
      const uniqueProjects = [...new Set(rawFinancialRecords.map(item => String(item.indicador || "").trim()))].filter(Boolean).sort();
      if (projectFilter) {
        const prevVal = projectFilter.value;
        projectFilter.innerHTML = '<option value="all">Todos os Projetos</option>';
        uniqueProjects.forEach(proj => {
          const opt = document.createElement("option");
          opt.value = proj;
          opt.textContent = proj;
          projectFilter.appendChild(opt);
        });
        if (prevVal && uniqueProjects.includes(prevVal)) {
          projectFilter.value = prevVal;
        }
      }

      // Popula o filtro de anos de forma dinâmica
      const uniqueYears = [...new Set(rawFinancialRecords.map(item => String(item.ano)))].sort();
      
      // Limpa e repovoa opções de anos
      yearFilter.innerHTML = '<option value="all">Todos os Anos</option>';
      uniqueYears.forEach(yr => {
        const opt = document.createElement("option");
        opt.value = yr;
        opt.textContent = `Ano ${yr}`;
        yearFilter.appendChild(opt);
      });

      // Aplica processamento inicial
      aggregateAndProcess();

      // Também executa a função carregarFinanceiro() para manter consistência e conformidade total de layout
      await carregarFinanceiro();

      loading.classList.add("hidden");
      content.classList.remove("hidden");
    } catch (err) {
      console.error("Erro ao carregar dados mensais:", err);
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = `Falha ao importar dados da tabela 'capex_monitoramento_mensal_'. Detalhes: ${err.message || err}`;
    }
  };

  if (yearFilter) {
    yearFilter.addEventListener("change", async () => {
      aggregateAndProcess();
      await carregarFinanceiro();
    });
  }
  if (projectFilter) {
    projectFilter.addEventListener("change", async () => {
      aggregateAndProcess();
      await carregarFinanceiro();
    });
  }
  if (cityFilter) {
    cityFilter.addEventListener("change", async () => {
      aggregateAndProcess();
      await carregarFinanceiro();
    });
  }
  if (refreshBtn) {
    refreshBtn.addEventListener("click", loadData);
  }

  loadData();
}

// Renderizador: Gráfico Mensal Barras Agrupadas Orçado x Realizado
function renderBarChart(labels, orcadoData, realizadoData) {
  const ctx = document.getElementById("monthlyBarChart").getContext("2d");

  if (window.instanceBarChart) {
    window.instanceBarChart.destroy();
  }

  window.instanceBarChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Previsto',
          data: orcadoData,
          backgroundColor: '#0b1f3a',
          borderRadius: 6,
          barPercentage: 0.8,
          categoryPercentage: 0.7
        },
        {
          label: 'Realizado',
          data: realizadoData,
          backgroundColor: '#00c2a8',
          borderRadius: 6,
          barPercentage: 0.8,
          categoryPercentage: 0.7
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          labels: {
            boxWidth: 12,
            boxHeight: 12,
            font: { family: 'Inter', size: 11, weight: '500' },
            color: '#475569'
          }
        },
        tooltip: {
          padding: 12,
          cornerRadius: 10,
          backgroundColor: '#0b1f3a',
          titleFont: { family: 'Inter', size: 12, weight: 'bold' },
          bodyFont: { family: 'Inter', size: 12 },
          callbacks: {
            label: function(context) {
              return ` ${context.dataset.label}: ${formatBRL(context.parsed.y)}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            font: { family: 'Inter', size: 10, weight: '500' },
            color: '#64748b'
          }
        },
        y: {
          border: { dash: [4, 4] },
          grid: { color: '#f1f5f9' },
          ticks: {
            font: { family: 'Inter', size: 10 },
            color: '#64748b',
            callback: function(value) {
              // Exibe rótulos resumidos (ex: R$ 10k, R$ 1M) para visual limpo
              if (value >= 1e6) {
                return (value / 1e6).toLocaleString('pt-BR') + 'M';
              }
              if (value >= 1e3) {
                return (value / 1e3).toLocaleString('pt-BR') + 'k';
              }
              return value;
            }
          }
        }
      }
    }
  });
}

// Renderizador: Gráfico de Linha Acumulada (S-Curve / Curva S)
function renderSCurveChart(labels, sOrcado, sRealizado) {
  const ctx = document.getElementById("sCurveChart").getContext("2d");

  if (window.instanceSCurveChart) {
    window.instanceSCurveChart.destroy();
  }

  window.instanceSCurveChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Acumulado Previsto (Planejado)',
          data: sOrcado,
          borderColor: '#0b1f3a',
          backgroundColor: 'transparent',
          borderWidth: 3,
          pointBackgroundColor: '#0b1f3a',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6,
          tension: 0.25
        },
        {
          label: 'Acumulado Realizado (Executado)',
          data: sRealizado,
          borderColor: '#00c2a8',
          backgroundColor: 'transparent',
          borderWidth: 3,
          pointBackgroundColor: '#00c2a8',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6,
          tension: 0.25
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          labels: {
            boxWidth: 12,
            boxHeight: 12,
            font: { family: 'Inter', size: 11, weight: '500' },
            color: '#475569'
          }
        },
        tooltip: {
          padding: 12,
          cornerRadius: 10,
          backgroundColor: '#0b1f3a',
          titleFont: { family: 'Inter', size: 12, weight: 'bold' },
          bodyFont: { family: 'Inter', size: 12 },
          callbacks: {
            label: function(context) {
              return ` ${context.dataset.label}: ${formatBRL(context.parsed.y)}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            font: { family: 'Inter', size: 10, weight: '500' },
            color: '#64748b'
          }
        },
        y: {
          border: { dash: [4, 4] },
          grid: { color: '#f1f5f9' },
          ticks: {
            font: { family: 'Inter', size: 10 },
            color: '#64748b',
            callback: function(value) {
              if (value >= 1e6) {
                return (value / 1e6).toLocaleString('pt-BR') + 'M';
              }
              if (value >= 1e3) {
                return (value / 1e3).toLocaleString('pt-BR') + 'k';
              }
              return value;
            }
          }
        }
      }
    }
  });
}

// 4) FUNÇÃO REQUISITADA: carregarFinanceiro()
async function carregarFinanceiro() {
  if (!supabase) {
    console.warn("Supabase ainda não foi devidamente carregado para carregarFinanceiro.");
    return;
  }

  const { data, error } = await supabase
    .from('capex_monitoramento_mensal_')
    .select('*')
    .order('ano')
    .order('mes')

  if (error) {
    console.error(error)
    return
  }

  // Obter o ano de filtro atualmente selecionado (se houver na página)
  const yearFilterEl = document.getElementById("year-filter");
  const selectedYear = yearFilterEl ? yearFilterEl.value : "all";

  // Obter o projeto de filtro atualmente selecionado (se houver na página)
  const projectFilterEl = document.getElementById("project-filter");
  const selectedProject = projectFilterEl ? projectFilterEl.value : "all";

  // Obter o filtro de cidade atualmente selecionado (se houver na página)
  const cityFilterEl = document.getElementById("city-filter");
  const selectedCity = cityFilterEl ? cityFilterEl.value : "all";

  const meses = {}

  data.forEach(item => {
    // Se houver filtro de ano específico ativado, pular itens que pertencem a outros anos
    if (selectedYear !== "all" && String(item.ano) !== selectedYear) {
      return;
    }

    // Se houver filtro de projeto específico ativado, pular itens que pertencem a outros projetos
    if (selectedProject !== "all" && String(item.indicador || "").trim() !== selectedProject) {
      return;
    }

    // Se houver filtro de cidade específico ativado, pular itens que pertencem a outras cidades
    if (selectedCity !== "all") {
      const cityLower = selectedCity.toLowerCase();
      const indicadorText = String(item.indicador || "").toLowerCase();
      if (!indicadorText.includes(cityLower)) {
        return;
      }
    }

    // 🔥 chave correta (mês + ano)
    const chave = `${item.ano}-${item.mes}`

    if (!meses[chave]) {
      let rawMesNome = String(item.mes_nome || "").trim();
      const mes_nome = rawMesNome.toLowerCase() === "marco" ? "Março" : rawMesNome;
      meses[chave] = {
        mes_nome: mes_nome,
        ano: item.ano,
        mes: item.mes,
        orcado: 0,
        realizado: 0
      }
    }

    const itemTipo = String(item.tipo || "").trim();
    // Normalizar para garantir que tanto "Orcado" quanto "Orçado" sejam reconhecidos
    const normalizedTipo = (itemTipo === "Orcado" || itemTipo === "orçado" || itemTipo === "orcamento" || itemTipo === "orçamento" || itemTipo.toLowerCase() === "orcado") ? "Orçado" : itemTipo;

    if (normalizedTipo === 'Orçado') {
      meses[chave].orcado += Number(item.valor || 0)
    }

    if (normalizedTipo === 'Realizado') {
      meses[chave].realizado += Number(item.valor || 0)
    }
  })

  // ordena corretamente
  const list = Object.values(meses).sort((a, b) => {
    if (a.ano !== b.ano) return a.ano - b.ano;
    return a.mes - b.mes;
  });

  let acumuladoOrcado = 0
  let acumuladoRealizado = 0

  const tbody = document.querySelector('#tabelaFinanceiro tbody')
  if (!tbody) {
    console.warn("Elemento #tabelaFinanceiro tbody não encontrado no DOM desta página.");
    return;
  }
  tbody.innerHTML = ""

  list.forEach(m => {

    acumuladoOrcado += m.orcado;
    acumuladoRealizado += m.realizado;

    const saldo = m.orcado - m.realizado
    const percentual = m.orcado > 0 
      ? ((m.realizado / m.orcado) * 100).toFixed(2)
      : "0.00"

    // Mostra Mês/Ano se visualizando múltiplos anos, senão apenas o nome do mês
    const displayMes = selectedYear === "all" ? `${m.mes_nome}/${m.ano}` : m.mes_nome;

    // Badge styling reflecting execution percentage limits
    let badgeClass = "bg-teal-50 text-teal-700 border-teal-100";
    const percentNum = parseFloat(percentual);
    if (percentNum >= 105 || percentNum < 35) {
      badgeClass = "bg-red-50 text-red-600 border-red-100";
    } else if (percentNum >= 90) {
      badgeClass = "bg-amber-50 text-amber-600 border-amber-100";
    }

    tbody.innerHTML += `
      <tr class="hover:bg-slate-50/80 transition duration-150 border-b border-slate-100">
        <td class="py-4 px-6 font-bold text-[#0b1f3a]">${displayMes}</td>
        <td class="py-4 px-6 text-right font-medium text-slate-700">R$ ${m.orcado.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
        <td class="py-4 px-6 text-right font-medium text-emerald-600">R$ ${m.realizado.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
        <td class="py-4 px-6 text-right font-medium ${saldo < 0 ? 'text-rose-600' : 'text-slate-500'}">R$ ${saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
        <td class="py-4 px-6 text-center">
          <span class="px-2.5 py-0.5 text-xs font-bold rounded-lg border ${badgeClass}">
            ${percentual}%
          </span>
        </td>
      </tr>
    `
  })
}

// Torna global para permitir chamada inline/testes manuais
window.carregarFinanceiro = carregarFinanceiro;

// ==========================================================
// 5) PEP CLASSIFICATION AND STRUCTURE MAP
// ==========================================================
const TIPO_ESTRUTURA_MAP = {
  "RC": { code: "RC", name: "REDE COLETORA", color: "bg-teal-50 text-teal-700 border-teal-200" },
  "LD": { code: "LD", name: "LIGAÇÃO DOMICILIAR", color: "bg-blue-50 text-blue-750 border-blue-200" },
  "IN": { code: "IN", name: "INTERCEPTOR", color: "bg-purple-50 text-purple-700 border-purple-200" },
  "LR": { code: "LR", name: "LINHA DE RECALQUE", color: "bg-cyan-50 text-cyan-700 border-cyan-200" },
  "EE": { code: "EE", name: "ESTAÇÃO ELEVATÓRIA", color: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  "TE": { code: "TE", name: "ESTAÇÃO DE TRATAMENTO", color: "bg-amber-50 text-amber-700 border-amber-200" },
  "PE": { code: "PE", name: "PROJETO", color: "bg-slate-50 text-slate-700 border-slate-200" }
};

function parseStructureType(pep) {
  const pepStr = String(pep || "").toUpperCase().trim();
  
  if (pepStr.includes("RC")) return TIPO_ESTRUTURA_MAP["RC"];
  if (pepStr.includes("LD")) return TIPO_ESTRUTURA_MAP["LD"];
  if (pepStr.includes("IN")) return TIPO_ESTRUTURA_MAP["IN"];
  if (pepStr.includes("LR")) return TIPO_ESTRUTURA_MAP["LR"];
  if (pepStr.includes("EE")) return TIPO_ESTRUTURA_MAP["EE"];
  if (pepStr.includes("TE") || pepStr.includes("ETA") || pepStr.includes("ETE") || pepStr.includes("TRAT")) {
    return TIPO_ESTRUTURA_MAP["TE"];
  }
  if (pepStr.includes("PE")) return TIPO_ESTRUTURA_MAP["PE"];
  
  // Secondary string fallback matches
  if (pepStr.includes("REDE")) return TIPO_ESTRUTURA_MAP["RC"];
  if (pepStr.includes("LIGA") || pepStr.includes("DOMIC")) return TIPO_ESTRUTURA_MAP["LD"];
  if (pepStr.includes("INTERC")) return TIPO_ESTRUTURA_MAP["IN"];
  if (pepStr.includes("RECALQ")) return TIPO_ESTRUTURA_MAP["LR"];
  if (pepStr.includes("ELEVAT") || pepStr.includes("ELEVA")) return TIPO_ESTRUTURA_MAP["EE"];
  if (pepStr.includes("PROJ")) return TIPO_ESTRUTURA_MAP["PE"];

  return TIPO_ESTRUTURA_MAP["PE"]; // Default fallback
}

// Helper to convert JS File to Base64 (needed for local persistence)
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
  });
}

// ==========================================================
// 6) LÓGICA DA TELA: CUSTO DE EXECUÇÃO POR CONTRATO (PEP)
// ==========================================================
async function initCustoExecucaoPage() {
  const loading = document.getElementById("loading-state");
  const errorState = document.getElementById("error-state");
  const content = document.getElementById("content-area");
  const errorMsg = document.getElementById("error-message");
  const refreshBtn = document.getElementById("btn-refresh");

  const filterContrato = document.getElementById("filter-contrato");
  const filterEstrutura = document.getElementById("filter-estrutura");

  let rawRazao = [];
  let uniqueContracts = [];

  const loadData = async () => {
    if (!supabaseClient) {
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = "Supabase não foi iniciado.";
      return;
    }

    loading.classList.remove("hidden");
    errorState.classList.add("hidden");
    content.classList.add("hidden");

    try {
      const { data, error } = await supabaseClient
        .from("razao_2026")
        .select("*");

      if (error) throw error;

      rawRazao = data || [];
      console.log("Dados da tabela razao_2026 carregados:", rawRazao.length);

      // Extrai contratos únicos para o filtro dropdown
      const contractsSet = new Set();
      rawRazao.forEach(r => {
        const p = String(r.projeto || "").trim();
        if (p) contractsSet.add(p);
      });
      uniqueContracts = Array.from(contractsSet).sort();

      // Altera o combo de filtro de contrato
      if (filterContrato) {
        filterContrato.innerHTML = '<option value="all">Todos os Contratos</option>';
        uniqueContracts.forEach(c => {
          const opt = document.createElement("option");
          opt.value = c;
          opt.textContent = c;
          filterContrato.appendChild(opt);
        });
      }

      // Renderiza inicialmente com filtros default
      renderFilteredResults();

      loading.classList.add("hidden");
      content.classList.remove("hidden");
    } catch (err) {
      console.error("Erro em initCustoExecucaoPage:", err);
      loading.classList.add("hidden");
      errorState.classList.remove("hidden");
      errorMsg.textContent = `Erro ao carregar livro razão razao_2026. Detalhes: ${err.message || err}`;
    }
  };

  const renderFilteredResults = () => {
    const selContrato = filterContrato ? filterContrato.value : "all";
    const selEstrutura = filterEstrutura ? filterEstrutura.value : "all";

    // Filtragem de dados
    const filtered = rawRazao.filter(item => {
      const matchContrato = selContrato === "all" || String(item.projeto).trim() === selContrato;
      
      const pepType = parseStructureType(item.elemento_pep);
      const matchEstrutura = selEstrutura === "all" || pepType.code === selEstrutura;

      return matchContrato && matchEstrutura;
    });

    // 1) ATUALIZA CARDS METRICOS
    const totalRazaoSoma = filtered.reduce((sum, item) => sum + (parseFloat(item.valor) || 0), 0);
    const qtLancamentos = filtered.length;

    // Calcula principal estrutura
    const estAcordoValor = {};
    filtered.forEach(item => {
      const pepType = parseStructureType(item.elemento_pep);
      estAcordoValor[pepType.name] = (estAcordoValor[pepType.name] || 0) + (parseFloat(item.valor) || 0);
    });

    let principalEst = "Nenhum";
    let maxEstVal = -1;
    for (const [name, val] of Object.entries(estAcordoValor)) {
      if (val > maxEstVal) {
        maxEstVal = val;
        principalEst = name;
      }
    }

    document.getElementById("card-total-razao").textContent = formatBRL(totalRazaoSoma);
    document.getElementById("card-qt-lancamentos").textContent = qtLancamentos;
    document.getElementById("card-principal-estrutura").textContent = principalEst;

    // 2) TABELA 1: RESUMO POR ITEM (ELEMENTO PEP) (Agrupado por "elemento_pep")
    const tabela1Total = document.getElementById("tabelaResumoContratoPEP");
    if (tabela1Total) {
      const tbody = tabela1Total.querySelector("tbody");
      tbody.innerHTML = "";

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="py-4 text-center text-slate-400">Nenhum lançamento corresponde aos filtros ativos.</td></tr>`;
      } else {
        const agrupadoItens = {};
        filtered.forEach(item => {
          const pep = String(item.elemento_pep || "PEP Sem Código").trim();
          const val = parseFloat(item.valor) || 0;
          const parentContract = String(item.projeto || "N/A").trim();
          const structure = parseStructureType(pep);

          if (!agrupadoItens[pep]) {
            agrupadoItens[pep] = {
              pep: pep,
              contrato: parentContract,
              estrutura: structure.name,
              color: structure.color,
              soma: 0
            };
          }
          agrupadoItens[pep].soma += val;
        });

        const list = Object.values(agrupadoItens).sort((a,b) => a.pep.localeCompare(b.pep));
        list.forEach(item => {
          const pctPart = totalRazaoSoma > 0 ? (item.soma / totalRazaoSoma) * 100 : 0;
          
          const tr = document.createElement("tr");
          tr.className = "hover:bg-slate-50 border-b border-slate-100 transition duration-150 font-medium";
          tr.innerHTML = `
            <td class="py-3 px-4">
              <span class="inline-block bg-slate-100 text-[#0b1f3a] font-mono text-[11px] px-2 py-0.5 rounded border border-slate-200/80 font-bold">${item.pep}</span>
            </td>
            <td class="py-3 px-4">
              <span class="inline-block bg-slate-50 text-slate-700 font-mono text-[11px] px-2 py-0.5 rounded border border-slate-200/80 font-bold">${item.contrato}</span>
            </td>
            <td class="py-3 px-4">
              <span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full border ${item.color}">${item.estrutura}</span>
            </td>
            <td class="py-3 px-4 text-right font-mono text-xs text-slate-700 font-bold">${formatBRL(item.soma)}</td>
            <td class="py-3 px-4 text-center font-mono text-xs text-indigo-650 font-bold">${formatPercent(pctPart)}</td>
          `;
          tbody.appendChild(tr);
        });
      }
    }

    // 3) TABELA 2: EXECUÇÃO POR TIPO ENGENHARIA (Agrupado por Categoria PEP)
    const tabela2Tipos = document.getElementById("tabelaExecucaoPorTipoPEP");
    if (tabela2Tipos) {
      const tbody = tabela2Tipos.querySelector("tbody");
      tbody.innerHTML = "";

      const tiposAcumulados = {};
      Object.keys(TIPO_ESTRUTURA_MAP).forEach(k => {
        tiposAcumulados[k] = 0;
      });

      filtered.forEach(item => {
        const info = parseStructureType(item.elemento_pep);
        tiposAcumulados[info.code] = (tiposAcumulados[info.code] || 0) + (parseFloat(item.valor) || 0);
      });

      const listEst = Object.keys(TIPO_ESTRUTURA_MAP).map(key => {
        return {
          code: key,
          name: TIPO_ESTRUTURA_MAP[key].name,
          color: TIPO_ESTRUTURA_MAP[key].color,
          valor: tiposAcumulados[key] || 0
        };
      }).sort((a, b) => b.valor - a.valor); // Mais utilizados no topo

      listEst.forEach(item => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-slate-50 border-b border-slate-100 transition duration-150 font-medium";
        tr.innerHTML = `
          <td class="py-3 px-4 text-center">
            <span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full border ${item.color}">${item.code}</span>
          </td>
          <td class="py-3 px-4 text-slate-700 text-xs font-semibold">${item.name}</td>
          <td class="py-3 px-4 text-right font-mono text-xs text-slate-700 font-bold">${formatBRL(item.valor)}</td>
        `;
        tbody.appendChild(tr);
      });
    }

    // 4) TABELA 3: FLUXO MENSAL ACUMULADO
    const tabela3Mensal = document.getElementById("tabelaExecucaoMensalPEP");
    if (tabela3Mensal) {
      const tbody = tabela3Mensal.querySelector("tbody");
      tbody.innerHTML = "";

      const agrupadoMeses = {};
      filtered.forEach(item => {
        const m = parseInt(item.mes) || 1;
        const name = String(item.mes_nome || `Mês ${m}`).trim();
        const val = parseFloat(item.valor) || 0;

        if (!agrupadoMeses[m]) {
          agrupadoMeses[m] = {
            mes: m,
            mes_nome: name,
            valor: 0
          };
        }
        agrupadoMeses[m].valor += val;
      });

      const sortedMeses = Object.values(agrupadoMeses).sort((a,b) => a.mes - b.mes);
      let acum = 0;
      sortedMeses.forEach(item => {
        acum += item.valor;
        const tr = document.createElement("tr");
        tr.className = "hover:bg-slate-50 border-b border-slate-100 transition duration-150 font-medium";
        tr.innerHTML = `
          <td class="py-3 px-4 text-slate-800 text-xs font-bold">${item.mes_nome}</td>
          <td class="py-3 px-4 text-right font-mono text-xs text-slate-500">${formatBRL(item.valor)}</td>
          <td class="py-3 px-4 text-right font-mono text-xs text-slate-700 font-bold bg-slate-50/40">${formatBRL(acum)}</td>
        `;
        tbody.appendChild(tr);
      });

      if (sortedMeses.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" class="py-4 text-center text-slate-400">Nenhum mês ativo.</td></tr>`;
      }
    }

    // 5) TABELA 4: DETALHE ANALÍTICO
    const tabela4Detalhe = document.getElementById("tabelaDetalheRazaoPEP");
    if (tabela4Detalhe) {
      const tbody = tabela4Detalhe.querySelector("tbody");
      tbody.innerHTML = "";

      filtered.forEach(item => {
        const st = parseStructureType(item.elemento_pep);
        const val = parseFloat(item.valor) || 0;

        const tr = document.createElement("tr");
        tr.className = "hover:bg-slate-50/50 border-b border-slate-100 transition duration-150 text-slate-700 font-medium";
        
        tr.innerHTML = `
          <td class="py-2.5 px-4">
            <span class="inline-block bg-slate-100 text-slate-700 font-mono text-[10px] px-2 py-0.5 rounded border border-slate-150 font-bold">${item.projeto || "N/A"}</span>
          </td>
          <td class="py-2.5 px-4 font-mono text-xs text-slate-500">${item.elemento_pep || "N/A"}</td>
          <td class="py-2.5 px-4">
            <span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-md border ${st.color}">${st.name}</span>
          </td>
          <td class="py-2.5 px-4 text-xs font-semibold text-slate-600 truncate max-w-[180px]" title="${item.fornecedor || ""}">${item.fornecedor || "N/A"}</td>
          <td class="py-2.5 px-4 text-right font-mono text-xs text-slate-800 font-bold">${formatBRL(val)}</td>
        `;
        tbody.appendChild(tr);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="py-8 text-center text-slate-450 bg-white">Sem lançamentos analíticos correspondentes.</td></tr>`;
      }
    }
  };

  // Event Listeners para filtragens
  if (filterContrato) filterContrato.addEventListener("change", renderFilteredResults);
  if (filterEstrutura) filterEstrutura.addEventListener("change", renderFilteredResults);

  if (refreshBtn) {
    refreshBtn.addEventListener("click", loadData);
  }

  // Inicializa
  loadData();
}

// ==========================================================
// 7) LÓGICA DA TELA: GESTÃO DE DOCUMENTOS (REPOSITÓRIO)
// ==========================================================
async function initDocumentosPage() {
  const tableBody = document.getElementById("documentos-table-body");
  const emptyDocsState = document.getElementById("empty-docs-state");
  const refreshBtn = document.getElementById("btn-refresh");

  const toggleUploadBtn = document.getElementById("toggle-upload-btn");
  const uploadFormContainer = document.getElementById("upload-form-container");
  const uploadChevron = document.getElementById("upload-chevron");

  const newDocForm = document.getElementById("new-document-form");
  const docContratoSelect = document.getElementById("doc-contrato");
  const docFileEl = document.getElementById("doc-file");
  const fileChosenText = document.getElementById("file-chosen-text");
  const uploadProgressText = document.getElementById("upload-progress-text");
  const uploadFeedback = document.getElementById("upload-feedback");

  const filterDocContrato = document.getElementById("filter-doc-contrato");
  const filterDocTipo = document.getElementById("filter-doc-tipo");
  const docCountBadge = document.getElementById("doc-count-badge");

  // Modal elements
  const docModal = document.getElementById("doc-modal");
  const closeModalBtn = document.getElementById("close-modal-btn");
  const modalCloseFooter = document.getElementById("modal-close-footer");
  const modalDocTitle = document.getElementById("modal-doc-title");
  const modalDocSubtitle = document.getElementById("modal-doc-subtitle");
  
  const modalPdfIframe = document.getElementById("modal-pdf-iframe");
  const modalPhotoImg = document.getElementById("modal-photo-img");
  const modalFallbackText = document.getElementById("modal-fallback-text");
  const modalDownloadFallbackBtn = document.getElementById("modal-download-fallback-btn");
  const modalDownloadBtn = document.getElementById("modal-download-btn");

  let documentsList = [];
  let contractsList = [];

  const loadPageData = async () => {
    if (!supabaseClient) return;

    try {
      // 1) Busca contratos para preencher selects
      const { data: contractsRes, error: contractsErr } = await supabaseClient
        .from("contratos")
        .select("*");

      if (contractsErr) throw contractsErr;

      contractsList = contractsRes || [];

      // Preenche selects de contratos
      if (docContratoSelect) {
        docContratoSelect.innerHTML = '<option value="">Selecione o Contrato...</option>';
        contractsList.forEach(c => {
          const opt = document.createElement("option");
          opt.value = c.codigo;
          opt.textContent = `${c.codigo} - ${c.nome}`;
          docContratoSelect.appendChild(opt);
        });
      }

      if (filterDocContrato) {
        filterDocContrato.innerHTML = '<option value="all">Todos os Contratos</option>';
        contractsList.forEach(c => {
          const opt = document.createElement("option");
          opt.value = c.codigo;
          opt.textContent = c.codigo;
          filterDocContrato.appendChild(opt);
        });
      }

      // 2) Busca documentos salvos
      await reloadDocumentsList();

    } catch (err) {
      console.error("Erro ao carregar dados da página de documentos:", err);
    }
  };

  const reloadDocumentsList = async () => {
    const { data: docsRes, error: docsErr } = await supabaseClient
      .from("documentos")
      .select("*");

    if (docsErr) {
      console.warn("Table 'documentos' missing, falling back to local simulation.", docsErr);
      documentsList = JSON.parse(localStorage.getItem("aegea_documents") || "[]");
    } else {
      documentsList = docsRes || [];
    }

    renderDocuments();
  };

  const renderDocuments = () => {
    if (!tableBody) return;

    const fContract = filterDocContrato ? filterDocContrato.value : "all";
    const fType = filterDocTipo ? filterDocTipo.value : "all";

    const filtered = documentsList.filter(d => {
      const matchContr = fContract === "all" || String(d.contrato).trim() === fContract;
      const matchT = fType === "all" || String(d.tipo).trim() === fType;
      return matchContr && matchT;
    });

    // Atualiza badge de contagem
    if (docCountBadge) {
      docCountBadge.textContent = `${filtered.length} Documentos salvos`;
    }

    tableBody.innerHTML = "";

    if (filtered.length === 0) {
      if (emptyDocsState) emptyDocsState.classList.remove("hidden");
      return;
    }

    if (emptyDocsState) emptyDocsState.classList.add("hidden");

    filtered.forEach(doc => {
      const tr = document.createElement("tr");
      tr.className = "border-b border-slate-100 hover:bg-slate-50 transition font-medium text-slate-700";

      // Tipo Badge Styling
      let tColor = "bg-slate-105 text-slate-600 border-slate-205";
      const tipo = String(doc.tipo).toLowerCase().trim();
      if (tipo === "contrato") tColor = "bg-blue-50 text-blue-700 border-blue-200/60";
      else if (tipo === "alvará") tColor = "bg-violet-50 text-violet-700 border-violet-200/60";
      else if (tipo === "licença") tColor = "bg-teal-50 text-teal-700 border-teal-200/60";
      else if (tipo === "projeto") tColor = "bg-indigo-50 text-indigo-700 border-indigo-200/60";
      else if (tipo === "medição") tColor = "bg-amber-50 text-amber-700 border-amber-200/60";

      tr.innerHTML = `
        <td class="py-3 px-6">
          <span class="inline-block bg-slate-100 text-[#0b1f3a] font-mono text-[11px] px-2 py-0.5 rounded border border-slate-200 font-bold">${doc.contrato}</span>
        </td>
        <td class="py-3 px-6">
          <span class="inline-block text-[10px] font-bold px-2.5 py-0.5 rounded-full border uppercase ${tColor}">${doc.tipo}</span>
        </td>
        <td class="py-3 px-6 font-semibold text-slate-800 text-xs max-w-sm truncate" title="${doc.nome_arquivo}">${doc.nome_arquivo}</td>
        <td class="py-3 px-6 font-mono text-xs text-slate-400">${doc.data_documento || "2026-06-01"}</td>
        <td class="py-3 px-6 text-center">
          <div class="flex items-center justify-center space-x-2">
            <button class="btn-visualizar text-teal-600 hover:text-white hover:bg-teal-500 border border-teal-200 px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1 shadow-xs bg-teal-50/40">
              <i data-lucide="eye" class="w-3.5 h-3.5"></i>
              <span>Visualizar</span>
            </button>
            <a href="${doc.url}" download="${doc.nome_arquivo}" class="text-slate-500 hover:text-slate-800 hover:bg-slate-100 border border-slate-200 p-1.5 rounded-lg transition" title="Baixar">
              <i data-lucide="download" class="w-3.5 h-3.5"></i>
            </a>
            <button class="btn-deletar-doc text-rose-500 hover:text-white hover:bg-rose-500 border border-rose-200 p-1.5 rounded-lg transition" data-nome="${doc.nome_arquivo}" data-url="${doc.url}" title="Excluir Documento">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
          </div>
        </td>
      `;

      // Event listener para visualização no modal
      const viewBtn = tr.querySelector(".btn-visualizar");
      viewBtn.addEventListener("click", () => {
        openDocumentModal(doc);
      });

      // Event listener para exclusão do documento
      const deleteBtn = tr.querySelector(".btn-deletar-doc");
      if (deleteBtn) {
        deleteBtn.addEventListener("click", async () => {
          const docName = deleteBtn.getAttribute("data-nome");
          const url = deleteBtn.getAttribute("data-url");

          if (!confirm(`Deseja realmente excluir o documento "${docName}" permanentemente?`)) return;

          deleteBtn.disabled = true;
          deleteBtn.innerHTML = `<span class="inline-block w-3.5 h-3.5 border-2 border-rose-500/30 border-t-rose-500 rounded-full animate-spin"></span>`;

          try {
            // 1) Deleta físico do storage se estiver lá
            if (url && url.includes("/documentos/")) {
              try {
                const parts = url.split("/documentos/");
                if (parts.length > 1) {
                  const pathName = decodeURIComponent(parts[1]);
                  if (supabaseClient && supabaseClient.storage && !supabaseClient.isMock) {
                    await supabaseClient.storage.from("documentos").remove([pathName]);
                    console.log("Arquivo deletado do bucket documentos:", pathName);
                  }
                }
              } catch (storageErr) {
                console.warn("Erro ao remover arquivo físico do bucket:", storageErr);
              }
            }

            // 2) Deleta registro do banco de dados na tabela documentos
            const { error } = await supabaseClient
              .from("documentos")
              .delete()
              .eq("nome_arquivo", docName);

            if (error) throw error;

            showFeedback("Documento excluído com sucesso!", "bg-emerald-100 text-emerald-800 border-emerald-300");
            await reloadDocumentsList();
          } catch (err) {
            console.error("Erro ao deletar documento:", err);
            showFeedback(`Erro ao deletar: ${err.message || err}`, "bg-red-100 text-red-700 border-red-300");
            deleteBtn.disabled = false;
            deleteBtn.innerHTML = `<i data-lucide="trash-2" class="w-3.5 h-3.5"></i>`;
          }
        });
      }

      tableBody.appendChild(tr);
    });

    if (window.lucide) {
      window.lucide.createIcons({ container: tableBody });
    }
  };

  // Abre modal do editor de mídia
  const openDocumentModal = (doc) => {
    if (!docModal) return;

    modalDocTitle.textContent = doc.nome_arquivo || "Visualizador Corporativo";
    modalDocSubtitle.textContent = `Vínculo: Contrato ${doc.contrato} • Tipo: ${doc.tipo.toUpperCase()}`;

    // Popula links de download
    if (modalDownloadBtn) modalDownloadBtn.href = doc.url;
    if (modalDownloadFallbackBtn) {
      modalDownloadFallbackBtn.href = doc.url;
      modalDownloadFallbackBtn.download = doc.nome_arquivo;
    }

    // Oculta todos por padrão
    modalPdfIframe.classList.add("hidden");
    modalPhotoImg.classList.add("hidden");
    modalFallbackText.classList.add("hidden");

    const url = String(doc.url || "");
    const ext = String(doc.nome_arquivo || "").toLowerCase();

    // Lógica inteligente para definir tipo de arquivo
    const isPDF = url.startsWith("data:application/pdf") || ext.endsWith(".pdf") || url.includes(".pdf");
    const isImg = url.startsWith("data:image/") || ext.endsWith(".png") || ext.endsWith(".jpg") || ext.endsWith(".jpeg") || ext.endsWith(".gif") || url.includes(".jpg") || url.includes(".png") || url.includes(".jpeg");

    if (isPDF) {
      modalPdfIframe.src = url;
      modalPdfIframe.classList.remove("hidden");
    } else if (isImg) {
      modalPhotoImg.src = url;
      modalPhotoImg.classList.remove("hidden");
    } else {
      // Fallback
      modalFallbackText.classList.remove("hidden");
    }

    docModal.classList.remove("hidden");
  };

  const closeDocumentModal = () => {
    if (docModal) docModal.classList.add("hidden");
    if (modalPdfIframe) modalPdfIframe.src = "";
    if (modalPhotoImg) modalPhotoImg.src = "";
  };

  // Bind fechar modal
  if (closeModalBtn) closeModalBtn.addEventListener("click", closeDocumentModal);
  if (modalCloseFooter) modalCloseFooter.addEventListener("click", closeDocumentModal);
  if (docModal) {
    docModal.addEventListener("click", (e) => {
      if (e.target === docModal) closeDocumentModal();
    });
  }

  // Toggle formulário de upload
  if (toggleUploadBtn) {
    toggleUploadBtn.addEventListener("click", () => {
      uploadFormContainer.classList.toggle("hidden");
      uploadChevron.classList.toggle("rotate-180");
    });
  }

  // Label amigável do arquivo carregado
  if (docFileEl) {
    docFileEl.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        fileChosenText.textContent = file.name;
        fileChosenText.className = "truncate pr-4 text-emerald-600 font-bold text-xs";
      } else {
        fileChosenText.textContent = "Escolher arquivo...";
        fileChosenText.className = "truncate pr-4 text-slate-500 text-xs";
      }
    });
  }

  // Submissão do formulário de upload
  if (newDocForm) {
    newDocForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const contrato = docContratoSelect.value;
      const tipo = document.getElementById("doc-tipo").value;
      const file = docFileEl.files[0];

      if (!contrato || !tipo || !file) {
        showFeedback("Por favor preencha todos os campos e anexe um arquivo válido.", "bg-red-100 text-red-700");
        return;
      }

      if (uploadProgressText) uploadProgressText.classList.remove("hidden");

      try {
        let fileUrl = "";

        // Tenta fazer upload para o storage verdadeiro do Supabase
        // Se falhar ou não existirem chaves, converte automaticamente em Base64
        try {
          if (supabaseClient && supabaseClient.storage) {
            const pathName = `${Date.now()}_${file.name}`;
            const { data, error } = await supabaseClient.storage
              .from("documentos")
              .upload(pathName, file);

            if (!error && data) {
              const { data: pubData } = supabaseClient.storage.from("documentos").getPublicUrl(pathName);
              fileUrl = pubData.publicUrl;
            }
          }
        } catch (storageErr) {
          console.warn("Storage corporativo inacessível. Salvando em Base64 na base em cache.", storageErr);
        }

        if (!fileUrl) {
          // Converte localmente em Base64
          fileUrl = await fileToBase64(file);
        }

        const newDocRecord = {
          contrato,
          tipo,
          nome_arquivo: file.name,
          url: fileUrl,
          data_documento: new Date().toISOString().split('T')[0]
        };

        const { data, error } = await supabaseClient
          .from("documentos")
          .insert([newDocRecord]);

        if (error) throw error;

        showFeedback(`Sucesso! O arquivo '${file.name}' foi carregado com sucesso para o bucket 'documentos'.`, "bg-emerald-100 text-emerald-800 border-emerald-300");
        
        // Reseta form e labels
        newDocForm.reset();
        if (fileChosenText) {
          fileChosenText.textContent = "Escolher arquivo...";
          fileChosenText.className = "truncate pr-4 text-slate-500 text-xs";
        }

        // Fecha Form
        uploadFormContainer.classList.add("hidden");
        uploadChevron.classList.remove("rotate-180");

        // Recarrega listagem
        await reloadDocumentsList();

      } catch (err) {
        console.error("Exceção ao inserir documento:", err);
        showFeedback(`Falha ao carregar documento: ${err.message || err}`, "bg-red-150 text-red-800 border-red-300");
      } finally {
        if (uploadProgressText) uploadProgressText.classList.add("hidden");
      }
    });
  }

  const showFeedback = (msg, cls) => {
    if (!uploadFeedback) return;
    uploadFeedback.innerHTML = msg;
    uploadFeedback.className = `p-3.5 rounded-xl text-xs font-semibold border ${cls}`;
    uploadFeedback.classList.remove("hidden");
    
    // Auto remove após 8 segundos
    setTimeout(() => {
      uploadFeedback.classList.add("hidden");
    }, 8000);
  };

  // Listeners de filtro
  if (filterDocContrato) filterDocContrato.addEventListener("change", renderDocuments);
  if (filterDocTipo) filterDocTipo.addEventListener("change", renderDocuments);

  if (refreshBtn) {
    refreshBtn.addEventListener("click", reloadDocumentsList);
  }

  // Inicializa carga de dados
  await loadPageData();
}

// ==========================================================
// 8) PARADA RETROCOMPATIBILIDADE LEGADA (DASHBOARD BOTTOM FLUX)
// ==========================================================
async function carregarCustoPorContrato() {
  const table = document.getElementById("tabelaResumoContrato");
  if (!table) return;
  const tbody = table.querySelector("tbody");
  if (!tbody) return;

  if (!supabaseClient) {
    console.warn("Supabase não iniciado para carregarCustoPorContrato.");
    return;
  }

  try {
    const { data, error } = await supabaseClient
      .from('razao_2026')
      .select('*');

    if (error) {
      console.error(error);
      return;
    }

    tbody.innerHTML = "";
    if (!data || data.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" class="py-4 text-center text-slate-400">Nenhum registro retornado pela tabela razao_2026.</td></tr>`;
      return;
    }

    const agrupado = {};
    data.forEach(item => {
      const proj = String(item.projeto || "Sem Contrato").trim();
      const val = parseFloat(item.valor) || 0;
      const forn = String(item.fornecedor || "Não Identificado").trim();

      if (!agrupado[proj]) {
        agrupado[proj] = {
          projeto: proj,
          custo_executado: 0,
          qt_lancamentos: 0,
          fornecedores: {}
        };
      }

      agrupado[proj].custo_executado += val;
      agrupado[proj].qt_lancamentos += 1;

      if (forn) {
        agrupado[proj].fornecedores[forn] = (agrupado[proj].fornecedores[forn] || 0) + val;
      }
    });

    const listaProjetos = Object.values(agrupado).sort((a, b) => a.projeto.localeCompare(b.projeto));

    listaProjetos.forEach(item => {
      let topForn = "Nenhum";
      let maxVal = -1;
      for (const [fornName, totalVal] of Object.entries(item.fornecedores)) {
        if (totalVal > maxVal) {
          maxVal = totalVal;
          topForn = fornName;
        }
      }

      const tr = document.createElement("tr");
      tr.className = "border-b border-slate-100/70 hover:bg-slate-50/50 transition-all duration-150 font-medium";

      let valClass = "text-[#0d9488]";
      if (item.custo_executado >= 1000000) {
        valClass = "text-[#e11d48] font-bold";
      } else if (item.custo_executado >= 500000) {
        valClass = "text-[#d97706] font-bold";
      }

      tr.innerHTML = `
        <td class="py-3 px-4">
          <span class="inline-block bg-slate-100 text-[#0b1f3a] font-mono px-2 py-0.5 rounded text-xs font-bold border border-slate-200">${item.projeto}</span>
        </td>
        <td class="py-3 px-4 text-right font-mono tracking-tight text-xs ${valClass}">${formatBRL(item.custo_executado)}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-block bg-slate-50 text-slate-600 font-mono text-xs px-2 py-0.5 rounded-full font-semibold border border-slate-200/65">${item.qt_lancamentos}</span>
        </td>
        <td class="py-3 px-4 text-slate-700 truncate max-w-[200px] text-xs" title="${topForn}">${topForn}</td>
      `;

      tbody.appendChild(tr);
    });

  } catch (err) {
    console.error(err);
  }
}

async function carregarExecucaoMensal() {
  const table = document.getElementById("tabelaExecucaoMensal");
  if (!table) return;
  const tbody = table.querySelector("tbody");
  if (!tbody) return;

  if (!supabaseClient) return;

  try {
    const { data, error } = await supabaseClient
      .from('razao_2026')
      .select('mes, mes_nome, valor');

    if (error) return;

    tbody.innerHTML = "";
    if (!data || data.length === 0) {
      tbody.innerHTML = `<tr><td colspan="3" class="py-4 text-[#0b1f3a]">Sem registros.</td></tr>`;
      return;
    }

    const agrupadoMes = {};
    data.forEach(item => {
      const mNum = parseInt(item.mes) || 1;
      const mName = String(item.mes_nome || `Mês ${mNum}`).trim();
      const val = parseFloat(item.valor) || 0;

      if (!agrupadoMes[mNum]) {
        agrupadoMes[mNum] = {
          mes: mNum,
          mes_nome: mName,
          valor_executado: 0
        };
      }
      agrupadoMes[mNum].valor_executado += val;
    });

    const listaMeses = Object.values(agrupadoMes).sort((a, b) => a.mes - b.mes);

    let acumulado = 0;
    listaMeses.forEach(item => {
      acumulado += item.valor_executado;
      
      const tr = document.createElement("tr");
      tr.className = "hover:bg-slate-50 border-b border-slate-100 transition duration-150 font-medium";

      let valClass = "text-[#0d9488]";
      if (item.valor_executado >= 2000000) {
        valClass = "text-[#e11d48] font-bold";
      } else if (item.valor_executado >= 1000000) {
        valClass = "text-[#d97706] font-bold";
      }

      tr.innerHTML = `
        <td class="py-3 px-4 font-bold text-[#0b1f3a] text-xs">${item.mes_nome}</td>
        <td class="py-3 px-4 text-right font-mono tracking-tight text-xs ${valClass}">${formatBRL(item.valor_executado)}</td>
        <td class="py-3 px-4 text-right font-mono tracking-tight text-xs font-bold text-slate-700 bg-slate-50/40">${formatBRL(acumulado)}</td>
      `;

      tbody.appendChild(tr);
    });

  } catch (err) {
    console.error(err);
  }
}

async function carregarDetalheRazao() {
  const table = document.getElementById("tabelaDetalheRazao");
  if (!table) return;
  const tbody = table.querySelector("tbody");
  if (!tbody) return;

  if (!supabaseClient) return;

  try {
    const { data, error } = await supabaseClient
      .from('razao_2026')
      .select('*')
      .order('mes', { ascending: true });

    if (error) return;

    tbody.innerHTML = "";
    if (!data || data.length === 0) return;

    data.forEach(item => {
      const val = parseFloat(item.valor) || 0;
      
      const tr = document.createElement("tr");
      tr.className = "border-b border-slate-150/50 hover:bg-slate-50/40 transition duration-150 font-medium text-slate-700";

      let valClass = "text-[#0d9488]";
      if (val >= 1000000) {
        valClass = "text-[#e11d48] font-bold";
      } else if (val >= 500000) {
        valClass = "text-[#d97706] font-bold";
      }

      tr.innerHTML = `
        <td class="py-2.5 px-5">
          <span class="inline-block bg-slate-100 text-slate-700 font-mono text-xs px-2 py-0.5 rounded border border-slate-200/80 font-bold">${item.projeto || "N/A"}</span>
        </td>
        <td class="py-2.5 px-5 text-slate-700 font-semibold text-xs truncate max-w-xs" title="${item.fornecedor || "N/A"}">${item.fornecedor || "N/A"}</td>
        <td class="py-2.5 px-5 text-center">
          <span class="inline-block bg-blue-50/60 text-blue-700 font-mono text-[11px] px-2 py-0.5 rounded-md border border-blue-100/80 font-semibold">${item.nf || "S/N"}</span>
        </td>
        <td class="py-2.5 px-5 text-right font-mono tracking-tight text-xs ${valClass}">${formatBRL(val)}</td>
      `;

      tbody.appendChild(tr);
    });

  } catch (err) {
    console.error(err);
  }
}

async function carregarCustoExecucao() {
  await Promise.all([
    carregarCustoPorContrato(),
    carregarExecucaoMensal(),
    carregarDetalheRazao()
  ]);
}

// Binds globais
window.carregarCustoPorContrato = carregarCustoPorContrato;
window.carregarExecucaoMensal = carregarExecucaoMensal;
window.carregarDetalheRazao = carregarDetalheRazao;
window.carregarCustoExecucao = carregarCustoExecucao;
window.initCustoExecucaoPage = initCustoExecucaoPage;
window.initDocumentosPage = initDocumentosPage;

